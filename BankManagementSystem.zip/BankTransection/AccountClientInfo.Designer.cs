﻿namespace BankTransection
{
    partial class AccountClientInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.ACCOUNTS = new System.Windows.Forms.TabPage();
            this.dataGridViewAccount = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridViewClient = new System.Windows.Forms.DataGridView();
            this.back = new System.Windows.Forms.Button();
            this.searchClear = new System.Windows.Forms.Button();
            this.lblSearch = new System.Windows.Forms.Label();
            this.AsearchBox = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.ACCOUNTS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAccount)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClient)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.ACCOUNTS);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1294, 555);
            this.tabControl1.TabIndex = 0;
            // 
            // ACCOUNTS
            // 
            this.ACCOUNTS.Controls.Add(this.dataGridViewAccount);
            this.ACCOUNTS.Location = new System.Drawing.Point(4, 22);
            this.ACCOUNTS.Name = "ACCOUNTS";
            this.ACCOUNTS.Padding = new System.Windows.Forms.Padding(3);
            this.ACCOUNTS.Size = new System.Drawing.Size(1286, 529);
            this.ACCOUNTS.TabIndex = 0;
            this.ACCOUNTS.Text = "ACCOUNTS";
            this.ACCOUNTS.UseVisualStyleBackColor = true;
            // 
            // dataGridViewAccount
            // 
            this.dataGridViewAccount.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewAccount.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.dataGridViewAccount.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewAccount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAccount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewAccount.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewAccount.Name = "dataGridViewAccount";
            this.dataGridViewAccount.ReadOnly = true;
            this.dataGridViewAccount.Size = new System.Drawing.Size(1280, 523);
            this.dataGridViewAccount.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridViewClient);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1286, 529);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "CLIENTS";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridViewClient
            // 
            this.dataGridViewClient.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewClient.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewClient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClient.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewClient.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewClient.Name = "dataGridViewClient";
            this.dataGridViewClient.ReadOnly = true;
            this.dataGridViewClient.Size = new System.Drawing.Size(1280, 523);
            this.dataGridViewClient.TabIndex = 0;
            // 
            // back
            // 
            this.back.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.back.BackColor = System.Drawing.Color.Red;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back.Location = new System.Drawing.Point(12, 562);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(105, 30);
            this.back.TabIndex = 21;
            this.back.Text = "<< BACK";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // searchClear
            // 
            this.searchClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.searchClear.BackColor = System.Drawing.Color.Gray;
            this.searchClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.searchClear.Location = new System.Drawing.Point(794, 559);
            this.searchClear.Name = "searchClear";
            this.searchClear.Size = new System.Drawing.Size(91, 30);
            this.searchClear.TabIndex = 24;
            this.searchClear.Text = "Clear";
            this.searchClear.UseVisualStyleBackColor = false;
            this.searchClear.Click += new System.EventHandler(this.searchClear_Click);
            // 
            // lblSearch
            // 
            this.lblSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(404, 561);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(88, 24);
            this.lblSearch.TabIndex = 23;
            this.lblSearch.Text = "SEARCH";
            // 
            // AsearchBox
            // 
            this.AsearchBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AsearchBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AsearchBox.Location = new System.Drawing.Point(498, 561);
            this.AsearchBox.Name = "AsearchBox";
            this.AsearchBox.Size = new System.Drawing.Size(290, 26);
            this.AsearchBox.TabIndex = 22;
            this.AsearchBox.TextChanged += new System.EventHandler(this.searchBox_TextChanged);
            // 
            // AccountClientInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1293, 599);
            this.Controls.Add(this.searchClear);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.AsearchBox);
            this.Controls.Add(this.back);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AccountClientInfo";
            this.Text = "AccountClientInfo";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AccountClientInfo_FormClosed);
            this.Load += new System.EventHandler(this.AccountClientInfo_Load);
            this.tabControl1.ResumeLayout(false);
            this.ACCOUNTS.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAccount)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClient)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage ACCOUNTS;
        private System.Windows.Forms.DataGridView dataGridViewAccount;
        private System.Windows.Forms.TabPage tabPage2;
        public System.Windows.Forms.Button back;
        private System.Windows.Forms.DataGridView dataGridViewClient;
        private System.Windows.Forms.Button searchClear;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.TextBox AsearchBox;

    }
}