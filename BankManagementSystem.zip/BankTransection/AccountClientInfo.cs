﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankTransection
{
    public partial class AccountClientInfo : Form
    {
        public AccountClientInfo()
        {
            InitializeComponent();
        }

        private void AccountClientInfo_Load(object sender, EventArgs e)
        {
            dataGridViewAccount.DataSource = new OdbDataProvider().getAccountInfoTable();
            dataGridViewClient.DataSource = new OdbDataProvider().getClientInfoTable();

        }

        private void back_Click(object sender, EventArgs e)
        {
            //HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
            this.Dispose(true); 
            
        }

        private void AccountClientInfo_FormClosed(object sender, FormClosedEventArgs e)
        {
           // HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
            this.Dispose(true);
        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        {
            if(tabControl1.SelectedTab==tabControl1.TabPages[0])
            dataGridViewAccount.DataSource = new OdbDataProvider().searchAccountTableInfo(AsearchBox.Text);
            else if(tabControl1.SelectedTab==tabControl1.TabPages[1])
            {
                dataGridViewClient.DataSource = new OdbDataProvider().searchClientTableInfo(AsearchBox.Text);
            }
        }

        private void searchClear_Click(object sender, EventArgs e)
        {
            AsearchBox.Clear();
        }

    
    }
}
