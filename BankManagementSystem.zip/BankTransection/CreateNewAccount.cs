﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankTransection
{
    public partial class CreateNewAccount : Form
    {
        public CreateNewAccount()
        {
            InitializeComponent();
        }
        public void reloadAccountTable()
        {
            dataGridViewCreateAccount.DataSource = new OdbDataProvider().getAccountInfoTable();
            dataGridViewCreateAccount.FirstDisplayedScrollingRowIndex = dataGridViewCreateAccount.RowCount - 1;
        }
        private void submit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("ARE YOU SURE TO SUBMIT ?", "CONFIRM", MessageBoxButtons.YesNo,MessageBoxIcon.Question);

            if (dialogResult == DialogResult.Yes)
            {

                string acctype = this.comboBox1.SelectedItem.ToString().ToUpper();
                int amnt = 0;
                if (!String.IsNullOrWhiteSpace(accname.Text) && !String.IsNullOrWhiteSpace(nid.Text) && !String.IsNullOrWhiteSpace(add.Text)
                    && !String.IsNullOrWhiteSpace(contact.Text) && !String.IsNullOrWhiteSpace(acctype) && int.TryParse(amount.Text, out amnt))
                {
                    if (amnt >= 500)
                    {
                        if (comboBox1.SelectedIndex == 0)
                        {
                            new OdbDataProvider().createNewCurrentAccount(accname.Text.ToUpper(), nid.Text, add.Text, contact.Text, acctype, amnt.ToString());
                        }
                        if (comboBox1.SelectedIndex == 1)
                        {
                            new OdbDataProvider().createNewFixAccount(accname.Text.ToUpper(), nid.Text, add.Text, contact.Text, acctype, amnt.ToString());
                        }
                        if (comboBox1.SelectedIndex == 2)
                        {
                            new OdbDataProvider().createNewCorporateAccount(accname.Text.ToUpper(), nid.Text.ToUpper(), add.Text, contact.Text, acctype, amnt.ToString());
                        }

                        reloadAccountTable();
                    }
                    else MessageBox.Show(" INVALID AMOUNT ", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else MessageBox.Show("ALL THE FILEDS NEED TO BE FILLED UP PROPERLY", "IMPROPER INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 2)
            {
                this.labelNid.Text = "AGENT NAME";
            }
            else
            {
                this.labelNid.Text = "NATIONAL ID";
            }
            reloadAccountTable();
        }

        private void CreateNewAccount_Load(object sender, EventArgs e)
        {
            reloadAccountTable();
        }

        private void CreateNewAccount_FormClosed(object sender, FormClosedEventArgs e)
        {
           // HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
            this.Dispose(true);
        }

        private void back_Click(object sender, EventArgs e)
        {
            //HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
            this.Dispose(true);
        }

        private void AsearchBox_TextChanged(object sender, EventArgs e)
        {
            dataGridViewCreateAccount.DataSource = new OdbDataProvider().searchAccountTableInfo(AsearchBox.Text);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            accname.Clear();
            nid.Clear();
            add.Clear();
            contact.Clear();
            amount.Clear();
            AsearchBox.Clear();
            reloadAccountTable();  
        }

        private void searchClear_Click(object sender, EventArgs e)
        {
            AsearchBox.Clear();
        }

        
    }
}
