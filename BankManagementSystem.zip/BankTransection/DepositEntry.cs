﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankTransection
{
    public partial class DepositEntry : Form
    {

        public DepositEntry()
        {
            InitializeComponent();
        }
        public void reloadDepositeTable()
        {
            dataGridDeposite.DataSource = new OdbDataProvider().getDepositTable();
            dataGridDeposite.FirstDisplayedScrollingRowIndex = dataGridDeposite.RowCount - 1;
            lableSum.Text = "";
        }
        private void DepositEntry_Load(object sender, EventArgs e)
        {
            reloadDepositeTable();
        }

        private void DepositEntry_FormClosed(object sender, FormClosedEventArgs e)
        {
            //HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
            this.Dispose(true);
        }

        private void BtnInsert_Click(object sender, EventArgs e)
        {
            String Date = date.Value.ToString("dd-MMM-yy");
            int bid,accno,amnt,rec;

            if (int.TryParse(b_id.Text, out bid) && int.TryParse(acc_no.Text, out accno) && int.TryParse(amount.Text, out amnt) && int.TryParse(receiver.Text, out rec))
            {
                if (amnt >= 500 && new OdbDataProvider().isAccountValid(acc_no.Text))
                {

                    new OdbDataProvider().inserIntoDepositTable(d_name.Text.ToUpper(), Date, bid, accno, amnt, rec);
                    reloadDepositeTable();

                }
                else MessageBox.Show("INVALID ACCOUNT OR AMOUNT","",MessageBoxButtons.OK, MessageBoxIcon.Error);
                    
            }
            else MessageBox.Show("INVALID ACCOUNT OR AMOUNT", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            reloadDepositeTable();
            acc_no.Clear();
            d_name.Clear();
            amount.Clear();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridDeposite.SelectedRows.Count > 0 && dataGridDeposite.SelectedRows[0].Cells[0].Value !=null)
            {
                int updateno = Convert.ToInt32(dataGridDeposite.SelectedRows[0].Cells[0].Value.ToString());
                string Name = dataGridDeposite.SelectedRows[0].Cells[1].Value.ToString();
                DateTime Dte = Convert.ToDateTime(dataGridDeposite.SelectedRows[0].Cells[2].Value.ToString());
                string Acc = dataGridDeposite.SelectedRows[0].Cells[4].Value.ToString();
                string Amnt = dataGridDeposite.SelectedRows[0].Cells[5].Value.ToString();
                
                Update up = new Update();
                up.d_name.Text = Name;
                up.acc_no.Text = Acc;
                up.datetime.Value =Dte;
                up.amount.Text = Amnt;
                up.acc_no.Enabled = false;
                up.previousAmnt = int.Parse(Amnt);
                
                up.dno = updateno;
               
                up.ShowDialog();
                reloadDepositeTable();
                

            }
            else MessageBox.Show("SELECT A ROW TO UPDATE", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        {
            dataGridDeposite.DataSource = new OdbDataProvider().searchDepositTable(searchBox.Text);
        }

        private void searchClear_Click(object sender, EventArgs e)
        {
            searchBox.Clear();
            reloadDepositeTable();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Dispose(true);
          //  HomePage.hp.Show();
            HomePage.hp.WindowState=FormWindowState.Maximized;
            HomePage.hp.BringToFront();
        }

        private void buttonSum_Click(object sender, EventArgs e)
        {

            int sum = 0;
            int val = 0;
            if (dataGridDeposite.SelectedRows.Count > 0 )
            {
                try{
                    for (int i = 0; i < dataGridDeposite.SelectedRows.Count; i++)
                    {
                        if(dataGridDeposite.SelectedRows[i].Cells[5].Value!=null)
                         if(int.TryParse(dataGridDeposite.SelectedRows[i].Cells[5].Value.ToString(), out val))
                         {
                            sum = sum + val;
                         }
                    }
                    
              }
            catch(Exception){ }
            }
            lableSum.Text = sum.ToString()+" BDT";
        }

        private void lableSum_Click(object sender, EventArgs e)
        {

        }

      
      
    }
}
