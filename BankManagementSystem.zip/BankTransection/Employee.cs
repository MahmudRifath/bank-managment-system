﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankTransection
{
    class Employee
    {
        public static Employee e;

        public int E_id { get; set; }
        public string E_name { get; set; }
        public string Job { get; set; }
        public int B_id { get; set; }
        public int D_id { get; set; }

        public string id_full;
    }
}
