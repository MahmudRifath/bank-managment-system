﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankTransection
{
    public partial class Form1 : Form
    {

        public static Form1 logInForm;
        public Form1()
        {
            InitializeComponent();
        }
        public void authenticate()
        {
            OdbDataProvider dp = new OdbDataProvider();

            bool confirm = dp.login(U_ID.Text, PASS.Text);
            if (confirm)
            {
                LStatus.Text = "SUCCESSFUL";
                //DepositEntry de = new DepositEntry();
                //de.receiver.Text = Employee.e.E_id.ToString();
                //de.b_id.Text = Employee.e.B_id.ToString();
                //this.Hide();
                //de.date.Value = DateTime.Today;
                //de.Show();
                logInForm = this;
                HomePage hp = new HomePage();
                hp.Show();
                PASS.Clear();
                U_ID.Clear();
                LStatus.Text = "LOGGED OUT";
                this.Hide();

            }
            else
                LStatus.Text = "UNSUCCESSFUL";

        }
        private void button1_Click(object sender, EventArgs e)
        {
            authenticate();            
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox3_MouseEnter(object sender, EventArgs e)
        {
            lblclose.BackColor = Color.Transparent;
            lblclose.Width += 3;
            lblclose.Height += 3;
        }

        private void lblclose_MouseLeave(object sender, EventArgs e)
        {
            lblclose.BackColor = Color.Transparent;
            lblclose.Width -= 3;
            lblclose.Height -= 3;
        }


        private void PASS_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter)
            {
                authenticate();
            }
        }

        private void pictureBox4_MouseEnter(object sender, EventArgs e)
        {
            lblminimize.Width += 3;
            lblminimize.Height += 3;
        }

        private void lblminimize_MouseLeave(object sender, EventArgs e)
        {
            lblminimize.Width -= 3;
            lblminimize.Height -= 3;
        }

    }
}
