﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankTransection
{
    public partial class Gmail : Form
    {
        public static Gmail gm;
        public Gmail()
        {
            InitializeComponent();
            gm = this;
        }

        private void Gmail_FormClosed(object sender, FormClosedEventArgs e)
        {
            gm.Hide();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            gm.Hide();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
        }
    }
}
