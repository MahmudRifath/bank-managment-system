﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BANKContext;
using LiveCharts.Wpf;
using LiveCharts;
namespace BankTransection
{
    public partial class Graph : Form
    {
        BANKDataContext db = new BANKDataContext();
        public Graph()
        {
            InitializeComponent();
        }

        private void Graph_Load(object sender, EventArgs e)
        {

            depositeGraph();
            withdrawGraph();
            transferGraph();

        }
        public void depositeGraph()
        {


            var dt = db.DEPOSITBYMONTHs;
            ColumnSeries col = new ColumnSeries() { DataLabels = true,Title=" BDT",Values = new ChartValues<decimal>(), LabelPoint = point => point.Y.ToString() };
            Axis ax = new Axis() { Separator = new Separator() { Step = 1, IsEnabled = false } };
            ax.Labels = new List<string>();
            foreach (var x in dt)
            {
                col.Values.Add(x.AMOUNT.Value);
                ax.Labels.Add(x.MONTH.ToString());
            }

            cartesianChart1.Series.Add(col);
            cartesianChart1.AxisX.Add(ax);
            cartesianChart1.AxisY.Add(new Axis { LabelFormatter = value => value.ToString(), Separator = new Separator() });

        }
        public void withdrawGraph()
        {
           

            var dt = db.WITHDRAWBYMONTHs;
            ColumnSeries col = new ColumnSeries() { DataLabels = true, Title = " BDT", Values = new ChartValues<decimal>(), LabelPoint = point => point.Y.ToString() };
            Axis ax = new Axis() { Separator = new Separator() { Step = 1, IsEnabled = false } };
            ax.Labels = new List<string>();
            foreach (var x in dt)
            {
                col.Values.Add(x.AMOUNT.Value);
                ax.Labels.Add(x.MONTH.ToString());
            }

            cartesianChart2.Series.Add(col);
            cartesianChart2.AxisX.Add(ax);
            cartesianChart2.AxisY.Add(new Axis { LabelFormatter = value => value.ToString(), Separator = new Separator() });


        }
        public void transferGraph()
        {
            var dt = db.TRANSFERBYMONTHs;
            ColumnSeries col = new ColumnSeries() { DataLabels = true, Title = " BDT", Values = new ChartValues<decimal>(), LabelPoint = point => point.Y.ToString() };
            Axis ax = new Axis() { Separator = new Separator() { Step = 1, IsEnabled = false } };
            ax.Labels = new List<string>();
            foreach (var x in dt)
            {
                col.Values.Add(x.AMOUNT.Value);
                ax.Labels.Add(x.MONTH.ToString());
            }

            cartesianChart3.Series.Add(col);
            cartesianChart3.AxisX.Add(ax);
            cartesianChart3.AxisY.Add(new Axis { LabelFormatter = value => value.ToString(), Separator = new Separator() });

        }

        private void Graph_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Dispose(true);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose(true);
        }

    }
}
