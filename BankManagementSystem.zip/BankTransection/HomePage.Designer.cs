﻿namespace BankTransection
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnGmail = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnDeposit = new System.Windows.Forms.Button();
            this.labeldeposit = new System.Windows.Forms.Label();
            this.labelinfo = new System.Windows.Forms.Label();
            this.labelgmail = new System.Windows.Forms.Label();
            this.labelinfo1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelName = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.circularProgressBar1 = new CircularProgressBar.CircularProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.labelhour = new System.Windows.Forms.Label();
            this.labelmin = new System.Windows.Forms.Label();
            this.labelDay = new System.Windows.Forms.Label();
            this.buttonGraph = new System.Windows.Forms.Button();
            this.labelBarChart = new System.Windows.Forms.Label();
            this.buttonEmp = new System.Windows.Forms.Button();
            this.buttonLoan = new System.Windows.Forms.Button();
            this.labelEmp1 = new System.Windows.Forms.Label();
            this.labelEmp2 = new System.Windows.Forms.Label();
            this.labelGloan = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGmail
            // 
            this.btnGmail.BackColor = System.Drawing.Color.White;
            this.btnGmail.BackgroundImage = global::BankTransection.Properties.Resources.rsz_gmail1600;
            this.btnGmail.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGmail.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGmail.Location = new System.Drawing.Point(816, 401);
            this.btnGmail.Name = "btnGmail";
            this.btnGmail.Size = new System.Drawing.Size(200, 200);
            this.btnGmail.TabIndex = 2;
            this.btnGmail.UseVisualStyleBackColor = false;
            this.btnGmail.Click += new System.EventHandler(this.btnGmail_Click);
            this.btnGmail.MouseEnter += new System.EventHandler(this.btnGmail_MouseEnter);
            this.btnGmail.MouseLeave += new System.EventHandler(this.btnGmail_MouseLeave);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.BackgroundImage = global::BankTransection.Properties.Resources.info_information_user_about_card_button_symbol_icon_512;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Location = new System.Drawing.Point(589, 265);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(200, 200);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            this.button2.MouseEnter += new System.EventHandler(this.button2_MouseEnter);
            this.button2.MouseLeave += new System.EventHandler(this.button2_MouseLeave);
            // 
            // btnDeposit
            // 
            this.btnDeposit.BackColor = System.Drawing.Color.White;
            this.btnDeposit.BackgroundImage = global::BankTransection.Properties.Resources.rsz_deposit;
            this.btnDeposit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeposit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDeposit.ForeColor = System.Drawing.Color.White;
            this.btnDeposit.Location = new System.Drawing.Point(589, 56);
            this.btnDeposit.Name = "btnDeposit";
            this.btnDeposit.Size = new System.Drawing.Size(200, 200);
            this.btnDeposit.TabIndex = 0;
            this.btnDeposit.UseVisualStyleBackColor = false;
            this.btnDeposit.Click += new System.EventHandler(this.button1_Click);
            this.btnDeposit.MouseEnter += new System.EventHandler(this.btnDeposit_MouseEnter);
            this.btnDeposit.MouseLeave += new System.EventHandler(this.btnDeposit_MouseLeave);
            // 
            // labeldeposit
            // 
            this.labeldeposit.AutoSize = true;
            this.labeldeposit.BackColor = System.Drawing.SystemColors.ControlText;
            this.labeldeposit.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldeposit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.labeldeposit.Location = new System.Drawing.Point(638, 227);
            this.labeldeposit.Name = "labeldeposit";
            this.labeldeposit.Size = new System.Drawing.Size(113, 25);
            this.labeldeposit.TabIndex = 3;
            this.labeldeposit.Text = "DEPOSIT";
            this.labeldeposit.Visible = false;
            // 
            // labelinfo
            // 
            this.labelinfo.AutoSize = true;
            this.labelinfo.BackColor = System.Drawing.SystemColors.ControlText;
            this.labelinfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelinfo.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelinfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.labelinfo.Location = new System.Drawing.Point(617, 435);
            this.labelinfo.Name = "labelinfo";
            this.labelinfo.Size = new System.Drawing.Size(154, 25);
            this.labelinfo.TabIndex = 4;
            this.labelinfo.Text = "CLIENT INFO";
            this.labelinfo.Visible = false;
            // 
            // labelgmail
            // 
            this.labelgmail.AutoSize = true;
            this.labelgmail.BackColor = System.Drawing.SystemColors.ControlText;
            this.labelgmail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelgmail.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelgmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.labelgmail.Location = new System.Drawing.Point(879, 571);
            this.labelgmail.Name = "labelgmail";
            this.labelgmail.Size = new System.Drawing.Size(86, 25);
            this.labelgmail.TabIndex = 5;
            this.labelgmail.Text = "G MAIL";
            this.labelgmail.Visible = false;
            // 
            // labelinfo1
            // 
            this.labelinfo1.AutoSize = true;
            this.labelinfo1.BackColor = System.Drawing.SystemColors.ControlText;
            this.labelinfo1.Font = new System.Drawing.Font("Papyrus", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelinfo1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.labelinfo1.Location = new System.Drawing.Point(591, 269);
            this.labelinfo1.Name = "labelinfo1";
            this.labelinfo1.Size = new System.Drawing.Size(191, 24);
            this.labelinfo1.TabIndex = 6;
            this.labelinfo1.Text = "ACCOUNTS AND";
            this.labelinfo1.Visible = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.BackgroundImage = global::BankTransection.Properties.Resources.rsz_pay_payment_icon_9;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Location = new System.Drawing.Point(363, 173);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 200);
            this.button1.TabIndex = 7;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            this.button1.MouseEnter += new System.EventHandler(this.button1_MouseEnter);
            this.button1.MouseLeave += new System.EventHandler(this.button1_MouseLeave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlText;
            this.label1.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(394, 343);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "TRANSFER";
            this.label1.Visible = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.BackgroundImage = global::BankTransection.Properties.Resources.rsz_usd_payment_icon_70450;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Location = new System.Drawing.Point(816, 168);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(200, 200);
            this.button3.TabIndex = 9;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            this.button3.MouseEnter += new System.EventHandler(this.button3_MouseEnter);
            this.button3.MouseLeave += new System.EventHandler(this.button3_MouseLeave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlText;
            this.label2.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label2.Location = new System.Drawing.Point(858, 338);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 25);
            this.label2.TabIndex = 10;
            this.label2.Text = "PAY LOAN";
            this.label2.Visible = false;
            // 
            // btnLogOut
            // 
            this.btnLogOut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLogOut.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLogOut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.ForeColor = System.Drawing.Color.Red;
            this.btnLogOut.Location = new System.Drawing.Point(16, 699);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(110, 29);
            this.btnLogOut.TabIndex = 11;
            this.btnLogOut.Text = "LOGOUT";
            this.btnLogOut.UseVisualStyleBackColor = false;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlText;
            this.label3.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label3.Location = new System.Drawing.Point(595, 644);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(186, 25);
            this.label3.TabIndex = 13;
            this.label3.Text = "NEW ACCOUNT";
            this.label3.Visible = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button4.BackgroundImage = global::BankTransection.Properties.Resources._138658_200;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Location = new System.Drawing.Point(588, 474);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(200, 200);
            this.button4.TabIndex = 12;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            this.button4.MouseEnter += new System.EventHandler(this.button4_MouseEnter);
            this.button4.MouseLeave += new System.EventHandler(this.button4_MouseLeave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlText;
            this.label4.Font = new System.Drawing.Font("Papyrus", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label4.Location = new System.Drawing.Point(363, 572);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(200, 27);
            this.label4.TabIndex = 15;
            this.label4.Text = "ISSUE CHEQUE";
            this.label4.Visible = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.BackgroundImage = global::BankTransection.Properties.Resources.Cheque;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(363, 403);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(200, 200);
            this.button5.TabIndex = 14;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            this.button5.MouseEnter += new System.EventHandler(this.button5_MouseEnter);
            this.button5.MouseLeave += new System.EventHandler(this.button5_MouseLeave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(14, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(152, 129);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.BackColor = System.Drawing.Color.Transparent;
            this.labelName.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelName.Location = new System.Drawing.Point(20, 147);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(67, 22);
            this.labelName.TabIndex = 18;
            this.labelName.Text = "NAME";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.RoyalBlue;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(140, 12);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(26, 30);
            this.button6.TabIndex = 19;
            this.button6.Text = "i";
            this.button6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // circularProgressBar1
            // 
            this.circularProgressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.circularProgressBar1.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.circularProgressBar1.AnimationSpeed = 999;
            this.circularProgressBar1.BackColor = System.Drawing.Color.Transparent;
            this.circularProgressBar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold);
            this.circularProgressBar1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.circularProgressBar1.InnerColor = System.Drawing.Color.Black;
            this.circularProgressBar1.InnerMargin = 4;
            this.circularProgressBar1.InnerWidth = -1;
            this.circularProgressBar1.Location = new System.Drawing.Point(1042, 16);
            this.circularProgressBar1.MarqueeAnimationSpeed = 200;
            this.circularProgressBar1.Maximum = 60;
            this.circularProgressBar1.Name = "circularProgressBar1";
            this.circularProgressBar1.OuterColor = System.Drawing.SystemColors.InfoText;
            this.circularProgressBar1.OuterMargin = -20;
            this.circularProgressBar1.OuterWidth = 18;
            this.circularProgressBar1.ProgressColor = System.Drawing.SystemColors.Highlight;
            this.circularProgressBar1.ProgressWidth = 15;
            this.circularProgressBar1.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.circularProgressBar1.Size = new System.Drawing.Size(240, 240);
            this.circularProgressBar1.StartAngle = 270;
            this.circularProgressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.circularProgressBar1.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar1.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circularProgressBar1.SubscriptText = ".23";
            this.circularProgressBar1.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar1.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circularProgressBar1.SuperscriptText = "°C";
            this.circularProgressBar1.TabIndex = 20;
            this.circularProgressBar1.Text = "~";
            this.circularProgressBar1.TextMargin = new System.Windows.Forms.Padding(-18, -50, 0, 0);
            this.circularProgressBar1.Value = 30;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // labelhour
            // 
            this.labelhour.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelhour.AutoSize = true;
            this.labelhour.BackColor = System.Drawing.Color.Black;
            this.labelhour.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelhour.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.labelhour.Location = new System.Drawing.Point(1088, 106);
            this.labelhour.Name = "labelhour";
            this.labelhour.Size = new System.Drawing.Size(69, 40);
            this.labelhour.TabIndex = 21;
            this.labelhour.Text = "HR";
            // 
            // labelmin
            // 
            this.labelmin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelmin.AutoSize = true;
            this.labelmin.BackColor = System.Drawing.Color.Black;
            this.labelmin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelmin.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.labelmin.Location = new System.Drawing.Point(1116, 172);
            this.labelmin.Name = "labelmin";
            this.labelmin.Size = new System.Drawing.Size(32, 18);
            this.labelmin.TabIndex = 22;
            this.labelmin.Text = "HR";
            this.labelmin.MouseClick += new System.Windows.Forms.MouseEventHandler(this.labelmin_MouseClick);
            // 
            // labelDay
            // 
            this.labelDay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelDay.AutoSize = true;
            this.labelDay.BackColor = System.Drawing.Color.Black;
            this.labelDay.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDay.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.labelDay.Location = new System.Drawing.Point(1142, 147);
            this.labelDay.Name = "labelDay";
            this.labelDay.Size = new System.Drawing.Size(32, 18);
            this.labelDay.TabIndex = 23;
            this.labelDay.Text = "HR";
            // 
            // buttonGraph
            // 
            this.buttonGraph.BackColor = System.Drawing.Color.White;
            this.buttonGraph.BackgroundImage = global::BankTransection.Properties.Resources.cartesian;
            this.buttonGraph.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonGraph.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonGraph.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonGraph.Location = new System.Drawing.Point(1036, 302);
            this.buttonGraph.Name = "buttonGraph";
            this.buttonGraph.Size = new System.Drawing.Size(200, 200);
            this.buttonGraph.TabIndex = 24;
            this.buttonGraph.UseVisualStyleBackColor = false;
            this.buttonGraph.Visible = false;
            this.buttonGraph.Click += new System.EventHandler(this.button7_Click);
            this.buttonGraph.MouseEnter += new System.EventHandler(this.buttonGraph_MouseEnter);
            this.buttonGraph.MouseLeave += new System.EventHandler(this.buttonGraph_MouseLeave);
            // 
            // labelBarChart
            // 
            this.labelBarChart.AutoSize = true;
            this.labelBarChart.BackColor = System.Drawing.SystemColors.ControlText;
            this.labelBarChart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelBarChart.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBarChart.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.labelBarChart.Location = new System.Drawing.Point(1070, 474);
            this.labelBarChart.Name = "labelBarChart";
            this.labelBarChart.Size = new System.Drawing.Size(145, 25);
            this.labelBarChart.TabIndex = 25;
            this.labelBarChart.Text = "BAR CHART";
            this.labelBarChart.Visible = false;
            // 
            // buttonEmp
            // 
            this.buttonEmp.BackColor = System.Drawing.Color.White;
            this.buttonEmp.BackgroundImage = global::BankTransection.Properties.Resources.manageEmp;
            this.buttonEmp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonEmp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonEmp.Location = new System.Drawing.Point(140, 403);
            this.buttonEmp.Name = "buttonEmp";
            this.buttonEmp.Size = new System.Drawing.Size(200, 200);
            this.buttonEmp.TabIndex = 26;
            this.buttonEmp.UseVisualStyleBackColor = false;
            this.buttonEmp.Visible = false;
            this.buttonEmp.Click += new System.EventHandler(this.button7_Click_1);
            this.buttonEmp.MouseEnter += new System.EventHandler(this.buttonEmp_MouseEnter);
            this.buttonEmp.MouseLeave += new System.EventHandler(this.buttonEmp_MouseLeave);
            // 
            // buttonLoan
            // 
            this.buttonLoan.BackColor = System.Drawing.Color.White;
            this.buttonLoan.BackgroundImage = global::BankTransection.Properties.Resources.rsz_homeloan_logo_t;
            this.buttonLoan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonLoan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonLoan.Location = new System.Drawing.Point(140, 173);
            this.buttonLoan.Name = "buttonLoan";
            this.buttonLoan.Size = new System.Drawing.Size(200, 200);
            this.buttonLoan.TabIndex = 27;
            this.buttonLoan.UseVisualStyleBackColor = false;
            this.buttonLoan.Visible = false;
            this.buttonLoan.Click += new System.EventHandler(this.button7_Click_2);
            this.buttonLoan.MouseEnter += new System.EventHandler(this.buttonLoan_MouseEnter);
            this.buttonLoan.MouseLeave += new System.EventHandler(this.buttonLoan_MouseLeave);
            // 
            // labelEmp1
            // 
            this.labelEmp1.AutoSize = true;
            this.labelEmp1.BackColor = System.Drawing.SystemColors.ControlText;
            this.labelEmp1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelEmp1.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmp1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.labelEmp1.Location = new System.Drawing.Point(184, 405);
            this.labelEmp1.Name = "labelEmp1";
            this.labelEmp1.Size = new System.Drawing.Size(112, 25);
            this.labelEmp1.TabIndex = 28;
            this.labelEmp1.Text = "MANAGE";
            this.labelEmp1.Visible = false;
            // 
            // labelEmp2
            // 
            this.labelEmp2.AutoSize = true;
            this.labelEmp2.BackColor = System.Drawing.SystemColors.ControlText;
            this.labelEmp2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelEmp2.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmp2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.labelEmp2.Location = new System.Drawing.Point(173, 574);
            this.labelEmp2.Name = "labelEmp2";
            this.labelEmp2.Size = new System.Drawing.Size(134, 25);
            this.labelEmp2.TabIndex = 29;
            this.labelEmp2.Text = "EMPLOYEE";
            this.labelEmp2.Visible = false;
            // 
            // labelGloan
            // 
            this.labelGloan.AutoSize = true;
            this.labelGloan.BackColor = System.Drawing.SystemColors.ControlText;
            this.labelGloan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelGloan.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGloan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.labelGloan.Location = new System.Drawing.Point(174, 343);
            this.labelGloan.Name = "labelGloan";
            this.labelGloan.Size = new System.Drawing.Size(133, 25);
            this.labelGloan.TabIndex = 30;
            this.labelGloan.Text = "GIVE LOAN";
            this.labelGloan.Visible = false;
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BankTransection.Properties.Resources.HomePageBackground;
            this.ClientSize = new System.Drawing.Size(1298, 741);
            this.Controls.Add(this.labelGloan);
            this.Controls.Add(this.labelEmp2);
            this.Controls.Add(this.labelEmp1);
            this.Controls.Add(this.labelBarChart);
            this.Controls.Add(this.labelDay);
            this.Controls.Add(this.labelmin);
            this.Controls.Add(this.labelhour);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.labeldeposit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.labelinfo1);
            this.Controls.Add(this.labelgmail);
            this.Controls.Add(this.labelinfo);
            this.Controls.Add(this.btnGmail);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnDeposit);
            this.Controls.Add(this.circularProgressBar1);
            this.Controls.Add(this.buttonGraph);
            this.Controls.Add(this.buttonLoan);
            this.Controls.Add(this.buttonEmp);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "HomePage";
            this.Text = "HomePage";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.HomePage_FormClosed);
            this.Load += new System.EventHandler(this.HomePage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDeposit;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnGmail;
        private System.Windows.Forms.Label labeldeposit;
        private System.Windows.Forms.Label labelinfo;
        private System.Windows.Forms.Label labelgmail;
        private System.Windows.Forms.Label labelinfo1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Button button6;
        private CircularProgressBar.CircularProgressBar circularProgressBar1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labelhour;
        private System.Windows.Forms.Label labelmin;
        private System.Windows.Forms.Label labelDay;
        private System.Windows.Forms.Button buttonGraph;
        private System.Windows.Forms.Label labelBarChart;
        private System.Windows.Forms.Button buttonEmp;
        private System.Windows.Forms.Button buttonLoan;
        private System.Windows.Forms.Label labelEmp1;
        private System.Windows.Forms.Label labelEmp2;
        private System.Windows.Forms.Label labelGloan;
    }
}