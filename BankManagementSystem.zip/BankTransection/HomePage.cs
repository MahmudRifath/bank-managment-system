﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BANKContext;
namespace BankTransection
{
    public partial class HomePage : Form
    {
        public static HomePage hp;
        public EMPLOYEET emp;
        //public Gmail gm;
        public HomePage()
        {
            InitializeComponent();
            hp = this;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DepositEntry de = new DepositEntry();
            de.receiver.Text = Employee.e.E_id.ToString();
            de.b_id.Text = Employee.e.B_id.ToString();
            de.date.Value = DateTime.Today;
            de.b_id.Enabled = false;
            de.receiver.Enabled = false;
            de.Show();

           // this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AccountClientInfo accl = new AccountClientInfo();
            accl.Show();
           // this.Hide();

        }

        private void btnGmail_Click(object sender, EventArgs e)
        {
            if (Gmail.gm == null || Gmail.gm.IsDisposed)
            {
                Gmail.gm = new Gmail();
                Gmail.gm.Show();
            }
            else
            {
                Gmail.gm.Show();
                Gmail.gm.WindowState = FormWindowState.Maximized;
            }
                
        }

        private void HomePage_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Transfer de = new Transfer();
            de.receiver.Text = Employee.e.E_id.ToString();
            de.b_id.Text = Employee.e.B_id.ToString();
            de.date.Value = DateTime.Today;
            de.b_id.Enabled = false;
            de.receiver.Enabled = false;
            de.Show();

          //  this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoanPayment de = new LoanPayment();
            de.receiver.Text = Employee.e.E_id.ToString();
            de.b_id.Text = Employee.e.B_id.ToString();
            de.date.Value = DateTime.Today;
            de.b_id.Enabled = false;
            de.receiver.Enabled = false;
            de.Show();

            //this.Hide();
        }

        private void btnDeposit_MouseEnter(object sender, EventArgs e)
        {
           // btnDeposit.BackColor = Color.SlateGray;
            labeldeposit.Visible = true;
            
        }

        private void btnDeposit_MouseLeave(object sender, EventArgs e)
        {
           // btnDeposit.BackColor = Color.Transparent;
            labeldeposit.Visible = false;
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
          //  button2.BackColor = Color.SlateGray;
            labelinfo.Visible = true;
            labelinfo1.Visible = true;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
           // button2.BackColor = Color.Transparent;
            labelinfo.Visible = false;
            labelinfo1.Visible = false;
        }

        private void btnGmail_MouseEnter(object sender, EventArgs e)
        {
           // btnGmail.BackColor = Color.SlateGray;
            labelgmail.Visible = true;
        }

        private void btnGmail_MouseLeave(object sender, EventArgs e)
        {
          //  btnGmail.BackColor = Color.Transparent;
            labelgmail.Visible = false;
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
         //   button1.BackColor = Color.SlateGray;
            label1.Visible = true;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {

          //  button1.BackColor = Color.Transparent;
            label1.Visible = false;
        }

        private void button3_MouseEnter(object sender, EventArgs e)
        {
          //  button3.BackColor = Color.SlateGray;
            label2.Visible = true;

        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
          //  button3.BackColor = Color.Transparent;
            label2.Visible = false;
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show(this, "ARE YOU SURE TO LOGOUT ??", "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogresult == DialogResult.Yes)
            {
                Form1.logInForm.Show();
                this.Dispose(true);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CreateNewAccount cn = new CreateNewAccount();
            cn.comboBox1.SelectedIndex = 0;
            cn.Show();
          //  this.Hide();
        }

        private void HomePage_Load(object sender, EventArgs e)
        {
            
            BANKDataContext db = new BANKDataContext();
            emp =db.EMPLOYEETs.SingleOrDefault(em=> em.EID==Employee.e.E_id);
            if(emp!=null)
            {
                pictureBox1.ImageLocation = emp.PHOTO;
                labelName.Text = emp.ENAME;
                if(emp.JOB.ToUpper().Equals("MANAGER"))
                {
                    buttonGraph.Visible = true;
                    buttonEmp.Visible = true;
                    buttonLoan.Visible = true;

                }
            }
        }

        private void button4_MouseEnter(object sender, EventArgs e)
        {
          //  button4.BackColor = Color.SlateGray;
            label3.Visible = true;
        }

        private void button4_MouseLeave(object sender, EventArgs e)
        {
          //  button4.BackColor = Color.Transparent;
            label3.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            W_Cheque wc = new W_Cheque();
            wc.Show();
        }


        private void button5_MouseEnter(object sender, EventArgs e)
        {
            label4.Visible = true;
        }

        private void button5_MouseLeave(object sender, EventArgs e)
        {
            label4.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Profile pf = new Profile(emp);
            
            pf.ShowDialog();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            circularProgressBar1.Value = Convert.ToInt32(DateTime.Now.ToString("ss"));
            labelhour.Text = DateTime.Now.ToString("hh:mm:ss");
            labelDay.Text = DateTime.Now.ToString("dddd");
            labelmin.Text = DateTime.Now.ToString("dd-MMMM-yy");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Graph grp = new Graph();
            grp.Show();
        }

        private void buttonGraph_MouseEnter(object sender, EventArgs e)
        {
            labelBarChart.Visible = true;
        }

        private void buttonGraph_MouseLeave(object sender, EventArgs e)
        {
            labelBarChart.Visible = false;
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            ManageEmp memp = new ManageEmp();
            memp.Show();
        }

        private void button7_Click_2(object sender, EventArgs e)
        {
            NewLoan l = new NewLoan();
            l.Show();

        }

        private void buttonLoan_MouseEnter(object sender, EventArgs e)
        {
            labelGloan.Visible = true;
        }

        private void buttonLoan_MouseLeave(object sender, EventArgs e)
        {
            labelGloan.Visible = false;
        }

        private void buttonEmp_MouseEnter(object sender, EventArgs e)
        {
            labelEmp1.Visible = true;
            labelEmp2.Visible = true;
        }

        private void buttonEmp_MouseLeave(object sender, EventArgs e)
        {
            labelEmp1.Visible = false;
            labelEmp2.Visible = false;
        }

        private void labelmin_MouseClick(object sender, MouseEventArgs e)
        {

            CalanderHp calander = new CalanderHp();
            calander.Show();
        }

        
       
    }
}
