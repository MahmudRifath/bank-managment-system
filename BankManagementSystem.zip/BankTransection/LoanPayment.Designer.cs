﻿namespace BankTransection
{
    partial class LoanPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.back = new System.Windows.Forms.Button();
            this.lblSearch = new System.Windows.Forms.Label();
            this.searchBox = new System.Windows.Forms.TextBox();
            this.BtnUpdate = new System.Windows.Forms.Button();
            this.dataGridPayment = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.date = new System.Windows.Forms.DateTimePicker();
            this.BtnInsert = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.receiver = new System.Windows.Forms.TextBox();
            this.b_id = new System.Windows.Forms.TextBox();
            this.amount = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.loan_id = new System.Windows.Forms.TextBox();
            this.searchClear = new System.Windows.Forms.Button();
            this.lableSum = new System.Windows.Forms.Label();
            this.buttonSum = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPayment)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // back
            // 
            this.back.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.back.BackColor = System.Drawing.Color.Red;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back.Location = new System.Drawing.Point(12, 601);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(138, 30);
            this.back.TabIndex = 27;
            this.back.Text = "<< BACK";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // lblSearch
            // 
            this.lblSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(552, 601);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(88, 24);
            this.lblSearch.TabIndex = 25;
            this.lblSearch.Text = "SEARCH";
            // 
            // searchBox
            // 
            this.searchBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.searchBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBox.Location = new System.Drawing.Point(646, 601);
            this.searchBox.Name = "searchBox";
            this.searchBox.Size = new System.Drawing.Size(290, 26);
            this.searchBox.TabIndex = 24;
            // 
            // BtnUpdate
            // 
            this.BtnUpdate.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.BtnUpdate.Location = new System.Drawing.Point(1137, 603);
            this.BtnUpdate.Name = "BtnUpdate";
            this.BtnUpdate.Size = new System.Drawing.Size(128, 23);
            this.BtnUpdate.TabIndex = 21;
            this.BtnUpdate.Text = "UPDATE";
            this.BtnUpdate.UseVisualStyleBackColor = true;
            this.BtnUpdate.Visible = false;
            // 
            // dataGridPayment
            // 
            this.dataGridPayment.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridPayment.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridPayment.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridPayment.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridPayment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridPayment.Location = new System.Drawing.Point(479, 12);
            this.dataGridPayment.Name = "dataGridPayment";
            this.dataGridPayment.ReadOnly = true;
            this.dataGridPayment.Size = new System.Drawing.Size(786, 534);
            this.dataGridPayment.TabIndex = 23;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Window;
            this.groupBox1.Controls.Add(this.date);
            this.groupBox1.Controls.Add(this.BtnInsert);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.receiver);
            this.groupBox1.Controls.Add(this.b_id);
            this.groupBox1.Controls.Add(this.amount);
            this.groupBox1.Controls.Add(this.name);
            this.groupBox1.Controls.Add(this.loan_id);
            this.groupBox1.Location = new System.Drawing.Point(30, 112);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(412, 400);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PAYMENT";
            // 
            // date
            // 
            this.date.CustomFormat = "dd-MMM-yy";
            this.date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date.Location = new System.Drawing.Point(267, 248);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(125, 26);
            this.date.TabIndex = 13;
            this.date.Value = new System.DateTime(2017, 7, 5, 0, 0, 0, 0);
            // 
            // BtnInsert
            // 
            this.BtnInsert.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BtnInsert.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnInsert.Location = new System.Drawing.Point(118, 335);
            this.BtnInsert.Name = "BtnInsert";
            this.BtnInsert.Size = new System.Drawing.Size(153, 30);
            this.BtnInsert.TabIndex = 12;
            this.BtnInsert.Text = "PAY";
            this.BtnInsert.UseVisualStyleBackColor = false;
            this.BtnInsert.Click += new System.EventHandler(this.BtnInsert_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 286);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "RECIVER";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "AMOUNT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "LOAN ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 228);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "BRANCH ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "NAME";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = global::BankTransection.Properties.Resources.reload_icon;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(298, 332);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 38);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // receiver
            // 
            this.receiver.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.receiver.Location = new System.Drawing.Point(119, 275);
            this.receiver.Name = "receiver";
            this.receiver.Size = new System.Drawing.Size(112, 29);
            this.receiver.TabIndex = 5;
            // 
            // b_id
            // 
            this.b_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_id.Location = new System.Drawing.Point(119, 218);
            this.b_id.Name = "b_id";
            this.b_id.Size = new System.Drawing.Size(112, 29);
            this.b_id.TabIndex = 4;
            // 
            // amount
            // 
            this.amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amount.Location = new System.Drawing.Point(119, 169);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(273, 29);
            this.amount.TabIndex = 3;
            // 
            // name
            // 
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(119, 117);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(273, 29);
            this.name.TabIndex = 2;
            // 
            // loan_id
            // 
            this.loan_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loan_id.Location = new System.Drawing.Point(119, 64);
            this.loan_id.Name = "loan_id";
            this.loan_id.Size = new System.Drawing.Size(273, 29);
            this.loan_id.TabIndex = 1;
            // 
            // searchClear
            // 
            this.searchClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.searchClear.BackColor = System.Drawing.Color.Gray;
            this.searchClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.searchClear.Location = new System.Drawing.Point(951, 599);
            this.searchClear.Name = "searchClear";
            this.searchClear.Size = new System.Drawing.Size(111, 28);
            this.searchClear.TabIndex = 26;
            this.searchClear.Text = "Clear";
            this.searchClear.UseVisualStyleBackColor = false;
            this.searchClear.Click += new System.EventHandler(this.searchClear_Click);
            // 
            // lableSum
            // 
            this.lableSum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lableSum.AutoSize = true;
            this.lableSum.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lableSum.Location = new System.Drawing.Point(623, 559);
            this.lableSum.Name = "lableSum";
            this.lableSum.Size = new System.Drawing.Size(81, 24);
            this.lableSum.TabIndex = 28;
            this.lableSum.Text = "TOTAL";
            this.lableSum.Click += new System.EventHandler(this.lableSum_Click);
            // 
            // buttonSum
            // 
            this.buttonSum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonSum.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonSum.CausesValidation = false;
            this.buttonSum.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSum.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSum.Location = new System.Drawing.Point(479, 556);
            this.buttonSum.Name = "buttonSum";
            this.buttonSum.Size = new System.Drawing.Size(138, 30);
            this.buttonSum.TabIndex = 29;
            this.buttonSum.Text = "SUM";
            this.buttonSum.UseVisualStyleBackColor = false;
            this.buttonSum.Click += new System.EventHandler(this.buttonSum_Click);
            // 
            // LoanPayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1294, 660);
            this.Controls.Add(this.lableSum);
            this.Controls.Add(this.buttonSum);
            this.Controls.Add(this.back);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.searchBox);
            this.Controls.Add(this.BtnUpdate);
            this.Controls.Add(this.dataGridPayment);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.searchClear);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LoanPayment";
            this.Text = "LoanPayment";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.LoanPayment_FormClosed);
            this.Load += new System.EventHandler(this.LoanPayment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPayment)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button back;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.Button BtnUpdate;
        public System.Windows.Forms.DataGridView dataGridPayment;
        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.DateTimePicker date;
        private System.Windows.Forms.Button BtnInsert;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.TextBox receiver;
        public System.Windows.Forms.TextBox b_id;
        public System.Windows.Forms.TextBox amount;
        public System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox loan_id;
        private System.Windows.Forms.Button searchClear;
        private System.Windows.Forms.Label lableSum;
        private System.Windows.Forms.Button buttonSum;
    }
}