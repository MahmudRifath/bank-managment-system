﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankTransection
{
    public partial class LoanPayment : Form
    {
        public LoanPayment()
        {
            InitializeComponent();
        }
        public void reloadPaymentTable()
        {
            dataGridPayment.DataSource = new OdbDataProvider().getLoanInfo();
            dataGridPayment.FirstDisplayedScrollingRowIndex = dataGridPayment.RowCount - 1;
            lableSum.Text = "";
        }

        private void BtnInsert_Click(object sender, EventArgs e)
        {
            String Date = date.Value.ToString("dd-MMM-yy");
            int bid, accno, amnt;

            if (int.TryParse(b_id.Text, out bid) && int.TryParse(loan_id.Text, out accno) && int.TryParse(amount.Text, out amnt))
            {
                if (amnt >= 500 && new OdbDataProvider().isPaymentIdValid(loan_id.Text))
                {
                    new OdbDataProvider().insertIntoPaymentTable(loan_id.Text,b_id.Text,amount.Text,Date,name.Text.ToUpper());
                    reloadPaymentTable();
                }
                else MessageBox.Show("INVALID ACCOUNT OR AMOUNT", "", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else MessageBox.Show("INVALID ACCOUNT OR AMOUNT", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void LoanPayment_Load(object sender, EventArgs e)
        {
            reloadPaymentTable();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            loan_id.Clear();
            name.Clear();
            amount.Clear();
            searchBox.Clear();
            reloadPaymentTable();

        }

        private void back_Click(object sender, EventArgs e)
        {
            //HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
            this.Dispose(true);
            
        }

        private void LoanPayment_FormClosed(object sender, FormClosedEventArgs e)
        {
           // HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
            this.Dispose(true);
            
        }

        private void buttonSum_Click(object sender, EventArgs e)
        {
            int sum = 0;
            int val = 0;
            if (dataGridPayment.SelectedRows.Count > 0)
            {
                try
                {
                    for (int i = 0; i < dataGridPayment.SelectedRows.Count; i++)
                    {
                        if (dataGridPayment.SelectedRows[i].Cells[5].Value != null)
                            if (int.TryParse(dataGridPayment.SelectedRows[i].Cells[5].Value.ToString(), out val))
                            {
                                sum = sum + val;
                            }
                    }

                }
                catch (Exception) { }
            }
            lableSum.Text = sum.ToString() + " BDT";
        }

        private void lableSum_Click(object sender, EventArgs e)
        {

        }

        private void searchClear_Click(object sender, EventArgs e)
        {
            searchBox.Clear();
        }

       
    }
}
