﻿namespace BankTransection
{
    partial class ManageEmp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManageEmp));
            this.dataGridEmp = new System.Windows.Forms.DataGridView();
            this.buttonShowDetails = new System.Windows.Forms.Button();
            this.labelPercent = new System.Windows.Forms.Label();
            this.amount = new System.Windows.Forms.TextBox();
            this.buttonAmount = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.searchClear = new System.Windows.Forms.Button();
            this.lblSearch = new System.Windows.Forms.Label();
            this.searchBox = new System.Windows.Forms.TextBox();
            this.back = new System.Windows.Forms.Button();
            this.buttonNewEmp = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridEmp)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridEmp
            // 
            this.dataGridEmp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridEmp.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridEmp.BackgroundColor = System.Drawing.Color.White;
            this.dataGridEmp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridEmp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridEmp.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.dataGridEmp.Location = new System.Drawing.Point(12, 12);
            this.dataGridEmp.Name = "dataGridEmp";
            this.dataGridEmp.ReadOnly = true;
            this.dataGridEmp.Size = new System.Drawing.Size(1264, 424);
            this.dataGridEmp.TabIndex = 16;
            this.dataGridEmp.DoubleClick += new System.EventHandler(this.dataGridEmp_DoubleClick);
            // 
            // buttonShowDetails
            // 
            this.buttonShowDetails.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonShowDetails.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonShowDetails.CausesValidation = false;
            this.buttonShowDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonShowDetails.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonShowDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonShowDetails.Location = new System.Drawing.Point(12, 462);
            this.buttonShowDetails.Name = "buttonShowDetails";
            this.buttonShowDetails.Size = new System.Drawing.Size(138, 30);
            this.buttonShowDetails.TabIndex = 17;
            this.buttonShowDetails.Text = "Details";
            this.buttonShowDetails.UseVisualStyleBackColor = false;
            this.buttonShowDetails.Click += new System.EventHandler(this.buttonShowDetails_Click);
            // 
            // labelPercent
            // 
            this.labelPercent.AutoSize = true;
            this.labelPercent.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPercent.Location = new System.Drawing.Point(5, 38);
            this.labelPercent.Name = "labelPercent";
            this.labelPercent.Size = new System.Drawing.Size(219, 18);
            this.labelPercent.TabIndex = 19;
            this.labelPercent.Text = "INCREASE OR DECREASE";
            // 
            // amount
            // 
            this.amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amount.Location = new System.Drawing.Point(245, 37);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(178, 29);
            this.amount.TabIndex = 18;
            // 
            // buttonAmount
            // 
            this.buttonAmount.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonAmount.CausesValidation = false;
            this.buttonAmount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAmount.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAmount.Location = new System.Drawing.Point(245, 84);
            this.buttonAmount.Name = "buttonAmount";
            this.buttonAmount.Size = new System.Drawing.Size(178, 30);
            this.buttonAmount.TabIndex = 20;
            this.buttonAmount.Text = "Update";
            this.buttonAmount.UseVisualStyleBackColor = false;
            this.buttonAmount.Click += new System.EventHandler(this.buttonAmount_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.buttonAmount);
            this.groupBox1.Controls.Add(this.labelPercent);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.amount);
            this.groupBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(847, 462);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(429, 131);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SALARY INCREMENT";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 15);
            this.label1.TabIndex = 21;
            this.label1.Text = "Use Negative to Decrease";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(183, 78);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 38);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // searchClear
            // 
            this.searchClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.searchClear.BackColor = System.Drawing.Color.Gray;
            this.searchClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.searchClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchClear.Location = new System.Drawing.Point(685, 584);
            this.searchClear.Name = "searchClear";
            this.searchClear.Size = new System.Drawing.Size(98, 31);
            this.searchClear.TabIndex = 24;
            this.searchClear.Text = "Clear";
            this.searchClear.UseVisualStyleBackColor = false;
            this.searchClear.Click += new System.EventHandler(this.searchClear_Click);
            // 
            // lblSearch
            // 
            this.lblSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblSearch.AutoSize = true;
            this.lblSearch.BackColor = System.Drawing.Color.Transparent;
            this.lblSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(295, 586);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(88, 24);
            this.lblSearch.TabIndex = 23;
            this.lblSearch.Text = "SEARCH";
            // 
            // searchBox
            // 
            this.searchBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.searchBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBox.Location = new System.Drawing.Point(389, 585);
            this.searchBox.Name = "searchBox";
            this.searchBox.Size = new System.Drawing.Size(290, 29);
            this.searchBox.TabIndex = 22;
            this.searchBox.TextChanged += new System.EventHandler(this.searchBox_TextChanged);
            // 
            // back
            // 
            this.back.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.back.BackColor = System.Drawing.Color.Red;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back.Location = new System.Drawing.Point(12, 587);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(112, 30);
            this.back.TabIndex = 29;
            this.back.Text = "<<  BACK";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // buttonNewEmp
            // 
            this.buttonNewEmp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonNewEmp.BackColor = System.Drawing.Color.MediumTurquoise;
            this.buttonNewEmp.CausesValidation = false;
            this.buttonNewEmp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNewEmp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNewEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNewEmp.Location = new System.Drawing.Point(300, 462);
            this.buttonNewEmp.Name = "buttonNewEmp";
            this.buttonNewEmp.Size = new System.Drawing.Size(206, 30);
            this.buttonNewEmp.TabIndex = 22;
            this.buttonNewEmp.Text = "ADD NEW EMPLOYEE";
            this.buttonNewEmp.UseVisualStyleBackColor = false;
            this.buttonNewEmp.Click += new System.EventHandler(this.buttonNewEmp_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.BackColor = System.Drawing.Color.MistyRose;
            this.button1.CausesValidation = false;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(567, 463);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(206, 30);
            this.button1.TabIndex = 30;
            this.button1.Text = "VALIDATE / INVALIDATE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ManageEmp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1288, 634);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonNewEmp);
            this.Controls.Add(this.back);
            this.Controls.Add(this.searchClear);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.searchBox);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonShowDetails);
            this.Controls.Add(this.dataGridEmp);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ManageEmp";
            this.Text = "ManageEmp";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ManageEmp_FormClosed);
            this.Load += new System.EventHandler(this.ManageEmp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridEmp)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.DataGridView dataGridEmp;
        private System.Windows.Forms.Button buttonShowDetails;
        private System.Windows.Forms.Label labelPercent;
        public System.Windows.Forms.TextBox amount;
        private System.Windows.Forms.Button buttonAmount;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button searchClear;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Button back;
        private System.Windows.Forms.Button buttonNewEmp;
        private System.Windows.Forms.Button button1;
    }
}