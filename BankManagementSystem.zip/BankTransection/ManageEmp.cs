﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BANKContext;
namespace BankTransection
{
    public partial class ManageEmp : Form
    {
        BANKDataContext db = new BANKDataContext();
        public ManageEmp()
        {
            InitializeComponent();
        }

        private void ManageEmp_Load(object sender, EventArgs e)
        {
            reloadEmpTable();
        }
        public void reloadEmpTable()
        {
            var d = db.EMPINFOs;

            var data = (from E in d  select E ).OrderBy(id=>id.EID);

            //var data = (from E in d where E.EID != Employee.e.E_id select E).OrderBy(id => id.EID);
      
            dataGridEmp.DataSource = data;
        
        }
        public void showEmpDetails()
        {
            int eno = 0;
            if (dataGridEmp.SelectedRows.Count > 0)
            {
                try
                {
                    {
                        if (dataGridEmp.SelectedRows[0].Cells[0].Value != null)
                            if (int.TryParse(dataGridEmp.SelectedRows[0].Cells[0].Value.ToString(), out eno))
                            {

                                EMPLOYEET emp = db.EMPLOYEETs.SingleOrDefault(em => em.EID == eno);
                                if (emp != null)
                                {
                                    Profile p = new Profile(emp);

                                    p.ShowDialog();
                                    p.BringToFront();
                                }
                            }
                    }

                }
                catch (Exception) { }

            }

        }
        private void ManageEmp_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Dispose(true);
          //HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
        }

        private void buttonShowDetails_Click(object sender, EventArgs e)
        {
            showEmpDetails();
        }

        private void buttonAmount_Click(object sender, EventArgs e)
        {
            
            if (dataGridEmp.SelectedRows.Count > 0)
            {
                try
                {
                    DialogResult dialogResult = MessageBox.Show(this,"ARE YOU SURE TO CHANGE SALARY BY "+amount.Text+" BDT?", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (dialogResult == DialogResult.Yes) { 
                    for (int i = 0; i < dataGridEmp.SelectedRows.Count; i++)
                    {
                        int salup = 0;
                        int eno = 0;

                        if (dataGridEmp.SelectedRows[i].Cells[0].Value != null && int.TryParse(amount.Text, out salup)) 
                        { 
                            if (int.TryParse(dataGridEmp.SelectedRows[i].Cells[0].Value.ToString(), out eno))
                            {
                                EMPLOYEET emp = db.EMPLOYEETs.SingleOrDefault(em => em.EID == eno);
                                if (emp != null)
                                {
                                    if (emp.SALARY + salup >= 5000 && Math.Abs(salup) <= 10000)
                                    {
                                        emp.SALARY += salup;
                                        
                                    }
                                    else MessageBox.Show(this,"MAXIMUM INCREMENTATION IS 10000 BDT \nOR A PERSION MINIMUM SALARY CAN NOT BE LESS THEN 5000 BDT","SORRY",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);

                                }
                            }
                        }
                        else MessageBox.Show(this, "INVALID AMOUNT OR SELECTED ROW IS NOT VALID", "PLEASE CHECK", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                    db.SubmitChanges();
                    reloadEmpTable();
                  }
                }
                catch (Exception) { }

            }
            else MessageBox.Show(this, "YOU HAVE TO SELECT AT LEAST ONE ROW ", "WAIT A SECOND!!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string key = searchBox.Text.ToUpper();
                var d = db.EMPINFOs;
                var data = (from E in d where  ((((E.EID.ToString()).StartsWith(key) || (E.EID.ToString()).EndsWith(key))) || E.ENAME.StartsWith(key) || E.ENAME.EndsWith(key) || E.JOB.StartsWith(key) || E.JOB.EndsWith(key))||E.STATUS.StartsWith(key) select E).OrderBy(id => id.EID);
               // var data = (from E in d where E.EID != Employee.e.E_id && ((((E.EID.ToString()).StartsWith(key) || (E.EID.ToString()).EndsWith(key))) || E.ENAME.StartsWith(key) || E.ENAME.EndsWith(key) || E.JOB.StartsWith(key) || E.JOB.EndsWith(key)) || E.STATUS.StartsWith(key) select E).OrderBy(id => id.EID);
               
                dataGridEmp.DataSource = data;
                
            }
            catch(Exception)
            {}
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            reloadEmpTable();
            amount.Clear();
            searchBox.Clear();
        }

        private void searchClear_Click(object sender, EventArgs e)
        {
            searchBox.Clear();
            reloadEmpTable();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Dispose(true);
            //HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
        }

        private void buttonNewEmp_Click(object sender, EventArgs e)
        {
            NewEmp nemp = new NewEmp();
            nemp.ShowDialog(this);

            reloadEmpTable();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            if (dataGridEmp.SelectedRows.Count == 1 && dataGridEmp.SelectedRows[0].Cells[0].Value != null )
            {
                try
                {
                    int eno;
                    DialogResult dialogResult = MessageBox.Show(this, "ARE YOU SURE TO CHANGE THE STATUS OF THE USER ?", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (dialogResult == DialogResult.Yes)
                    {
                        if (int.TryParse(dataGridEmp.SelectedRows[0].Cells[0].Value.ToString(), out eno))
                        {

                            LOGIN login = db.LOGINs.SingleOrDefault(l => l.EID == eno);
                            if (login != null)
                            {

                                if (login.STATUS.Equals("VALID"))
                                {
                                    login.STATUS = "INVALID";
                                }
                                else if (login.STATUS.Equals("INVALID"))
                                {
                                    login.STATUS = "VALID";
                                }

                                db.SubmitChanges();

                                MessageBox.Show(this, "THE USER IS NOW " + login.STATUS, " INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                reloadEmpTable();
                            }
                        }
                        else MessageBox.Show(this, "PLEASE SELECT A SINGLE ROW \n OR SELECTED ROW IS NOT VALID ", "PLEASE CHECK", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }
                catch (Exception) { }

            }
            else MessageBox.Show(this, "PLEASE SELECT A SINGLE ROW \n OR SELECTED ROW IS NOT VALID ", "WAIT A SECOND!!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void dataGridEmp_DoubleClick(object sender, EventArgs e)
        {
            showEmpDetails();

        }
    }
}
