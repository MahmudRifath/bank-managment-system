﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BANKContext;
namespace BankTransection
{
    public partial class NewEmp : Form
    {
        public static string path;
        public BANKDataContext db = new BANKDataContext();

        public NewEmp()
        {
            InitializeComponent();
        }

        private void NewEmp_Load(object sender, EventArgs e)
        {
            try
            {

                var cdid = (from d in db.EMPLOYEETs select d.DID).Distinct().OrderBy(DID => DID);
                var cbid = (from b in db.EMPLOYEETs select b.BID).Distinct().OrderBy(BID => BID);
                var cjob = (from j in db.EMPLOYEETs select j.JOB).Distinct().OrderBy(JOB => JOB);

                dept.DataSource = cdid;
                dept.SelectedIndex = 0;

                job.DataSource = cjob;
                job.SelectedIndex = 0;

                bid.DataSource = cbid;
                bid.SelectedIndex = 0;
            }
            catch(Exception)
            {}

        }

      

        private void button1_Click(object sender, EventArgs e)
        {
            path = "none";
            OpenFileDialog f = new OpenFileDialog();
            f.Filter = "JPG FILES(*.jpg)|*.jpg|PNG FILES(*.png)|*.png|ALL FILES(*.*)|*.*";
            if (f.ShowDialog() == DialogResult.OK)
            {
                path = f.FileName.ToString();
                pictureBox1.ImageLocation = path;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void buttonCreate_Click(object sender, EventArgs e)
        {
            try
            {
                var eid = db.EMPLOYEETs.Max(id => id.EID);
                int sal = 0;

                if (int.TryParse(salary.Text, out sal) && !string.IsNullOrWhiteSpace(path) && !string.IsNullOrWhiteSpace(name.Text) && !string.IsNullOrWhiteSpace(salary.Text) && !string.IsNullOrWhiteSpace(mail.Text) && !string.IsNullOrWhiteSpace(job.Text))
                {
                    EMPLOYEET emp = new EMPLOYEET();

                    emp.EID = eid + 1;
                    emp.ENAME = name.Text.ToUpper();
                    emp.SALARY = sal;
                    emp.JOB = job.Text;
                    emp.BID = int.Parse(bid.Text);
                    emp.DID = int.Parse(dept.Text);
                    emp.PHOTO = path;
                    emp.HIREDATE = System.DateTime.Today;
                    emp.MAIL = mail.Text;
                    


                    LOGIN login = new LOGIN();
                    login.EID = emp.EID;
                    login.UID = System.DateTime.Today.ToString("yy") + '-' + emp.EID + '-' + emp.DID;
                    login.PASSWORD = "test";
                    login.STATUS = "VALID";
                    db.EMPLOYEETs.InsertOnSubmit(emp);
                    db.LOGINs.InsertOnSubmit(login);

                    db.SubmitChanges();

                    //DialogResult result = 
                        MessageBox.Show("SUCCESSFULLY CREATED \n USER ID : " + login.UID, "RESULT", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //if (result == DialogResult.OK)
                   // {
                        //this.Dispose(true);
                  //  }

                        name.Clear();
                        mail.Clear();
                        salary.Clear();
                        pictureBox1.ImageLocation = "";
                        path = "";

                }
                else MessageBox.Show("PLEASE FILL UP ALL THE INFORMATION PROPERLY \nINCLUDING SELECTION OF IMAGE", "ERROR !!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
            }
            catch(Exception)
            { }

        }

        private void NewEmp_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Dispose(true);
        }

    }
}
