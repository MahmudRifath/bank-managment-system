﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BANKContext;
namespace BankTransection
{
    public partial class NewLoan : Form
    {
        BANKDataContext db = new BANKDataContext();
        public NewLoan()
        {
            InitializeComponent();
        }

        public void reloadLoanTable()
        {
            var data = from d in db.LOANs orderby d.LOANID select d;
            if (data != null)
                dataGridLoan.DataSource = data;

        }


        private void BtnCreate_Click(object sender, EventArgs e)
        {
            var loan_id = db.LOANs.Max(x => x.LOANID);

            int amnt = 0;
            int mnth = 0;
            double rate = 0;
            if (int.TryParse(textBoxamount.Text, out amnt) && int.TryParse(textBoxmonth.Text, out mnth) && double.TryParse(textBoxRate.Text, out rate) && !string.IsNullOrWhiteSpace(textBoxaccno.Text) && !string.IsNullOrWhiteSpace(textBoxLoanOn.Text) && new OdbDataProvider().isAccountValid(textBoxaccno.Text))
            {
                if (rate > 0 && amnt >= 5000)
                {
                    try
                    {
                        LOAN ln = new LOAN();
                        ln.LOANID = (int.Parse(loan_id) + 1).ToString();
                        ln.INTERESTRATE = (rate / 100).ToString();
                        ln.LOANON = textBoxLoanOn.Text.ToUpper();
                        ln.DURATIONMONTH = mnth;
                        ln.AMOUNT = amnt;
                        ln.ACCOUNT = textBoxaccno.Text;
                        ln.TOBEPAID = amnt +(int)( amnt * (rate/100));
                        ln.APPROVER = Employee.e.E_id;

                        db.LOANs.InsertOnSubmit(ln);
                        db.SubmitChanges();
                        reloadLoanTable();
                    }
                    catch (Exception)
                    { }
                }
                else MessageBox.Show(this, "AMOUNT SHOULD BE 5000 BDT OR MORE \nOR INVALID INTEREST PERCENTEAGE ", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show(this, "INVALID ACCOUNT OR ALL THE FILEDS MUST BE FILLED PROPERLY", "", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void NewLoan_Load(object sender, EventArgs e)
        {
            reloadLoanTable();
        }

        private void back_Click(object sender, EventArgs e)
        {

            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
            this.Dispose(true);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            textBoxaccno.Clear();
            textBoxamount.Clear();
            textBoxLoanOn.Clear();
            textBoxmonth.Clear();
            textBoxRate.Clear();
            
            reloadLoanTable();
        }
    }
}
