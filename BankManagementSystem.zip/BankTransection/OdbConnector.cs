﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
namespace BankTransection
{
    class OdbConnector
    {
        public static OleDbConnection con;
        public static OleDbConnection getConnection()
        {
            return con = new OleDbConnection("Provider = MSDAORA;Data Source=XE;Persist Security Info=True;User ID=BANK;Password=BANK;Unicode=True");

        }

    }
}
