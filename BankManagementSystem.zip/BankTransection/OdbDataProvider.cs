﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data;
using BANKContext;
namespace BankTransection
{
    class OdbDataProvider
    {
        public static OleDbConnection con;
        public static OleDbDataAdapter da;
        public OdbDataProvider()
        {
            con = OdbConnector.getConnection();
            da = new OleDbDataAdapter();
        }

        public bool login(string uid, string pass)
        {    int i=0;
            con.Open();
            string query = "select * from login where u_ID='" + uid + "' and password='" + pass + "'";
            DataTable dt = new DataTable();

            try
            {
                OleDbDataAdapter user = new OleDbDataAdapter(query, con);
                user.Fill(dt);

            }
            catch(Exception)
            {

            }
            i= dt.Rows.Count;
            con.Close();

            

            if (i == 1)
            {   
                string[] s = uid.Split('-');
               LOGIN loginstatus=new BANKDataContext().LOGINs.SingleOrDefault(l=>l.EID==int.Parse(s[1]));

                if (loginstatus.STATUS.Equals("VALID"))
             //   if(true)
                {
                    Employee e = new Employee();
                    e.E_id = int.Parse(s[1]);
                    e.D_id = int.Parse(s[2]);
                    e.id_full = uid;
                    con.Open();
                    string query1 = "select * from EMPLOYEE where E_ID=" + s[1] + " and D_ID=" + s[2];

                    OleDbDataAdapter user1 = new OleDbDataAdapter(query1, con);

                    dt.Clear();
                    user1.Fill(dt);
                    e.E_name = dt.Rows[0]["E_NAME"].ToString();
                    e.Job = dt.Rows[0]["JOB"].ToString();
                    e.B_id = int.Parse(dt.Rows[0]["B_ID"].ToString());

                    Employee.e = e;
                    return true;
                }
                else
                    return false;
               }
            
            else
                return false;

        }

        public bool isAccountValid(string accno)
        {
            con.Open();
            string query = "select * from account where acc_no="+accno;

            OleDbDataAdapter user = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();
            user.Fill(dt);
            int i = dt.Rows.Count;
            con.Close();

            if (i == 1) { return true; }
            else
                return false;
        }

        public  DataTable getDepositTable()
        {
            
            con.Open();
            string query = "select * from DEPOSIT_STATUS order by "+'"'+"DEPOSIT NO"+'"';

            OleDbDataAdapter user = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();

            user.Fill(dt);
            con.Close();

            return dt;

        }
        public void updateAccountBalance(string accno,int amount)
        {
              con.Open();
                OleDbCommand cmd = new OleDbCommand("upBalance", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("accno", OleDbType.Numeric).Value = accno;
                cmd.Parameters.Add("amount", OleDbType.Numeric).Value = amount;

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                cmd.ExecuteNonQuery();

                con.Close();
            

        }
        public void inserIntoDepositTable(String d_name,String date,int B_ID,int acc_no,int amount,int receiver)
        {
            
            string query = "insert into deposit values(deposit_no.nextval ,'" + d_name + "','" + date + "'," + B_ID + "," + acc_no + "," + amount + "," + receiver + ")";
            
            con.Open();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();

            }
            catch(Exception)
            {}
            con.Close();

            updateAccountBalance(acc_no.ToString(), amount);
    
        }
        public void updateDepositTable(string accno,string dname ,int uamnt,string date,int dno,int iamnt)
        {
            string query = "update deposit set acc_no="+accno+",d_name='"+dname+"',amount="+ iamnt+",d_date='"+date+"'where d_no="+dno;
            con.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            cmd.CommandText = query;
            cmd.ExecuteNonQuery();
            con.Close();

            updateAccountBalance(accno, uamnt);
        }
        public DataTable searchDepositTable(string key)
        {
            con.Open();
            string query = "select * from DEPOSIT_STATUS where to_char(account) like '%" + key + "%'  or " + '"' + "RECEIVER NAME" + '"' + " like '%" + key.ToUpper() + "%'  or " + '"' + "DEPOSITER NAME" + '"' + " like '%" + key.ToUpper() + "%' order by " + '"' + "DEPOSIT NO" + '"';
            //string query = "select * from DEPOSIT_STATUS where to_char(account) like '%" + key + "%'  or " + '"' + "RECEIVER NAME" + '"' + " like '%" + key.ToUpper() + "%'  or " + '"' + "DEPOSITER NAME" + '"' + " like '%" + key.ToUpper() + "%' or "+'"' + "DATE" + '"' + " like to_date('" + key +"','mm/dd/yy')"+ " order by " + '"' + "DEPOSIT NO" + '"';
           // string query = "select * from DEPOSIT_STATUS where to_char(account) like '%" + key + "%'  or " + '"' + "RECEIVER NAME" + '"' + " like '%" + key.ToUpper() + "%'  or " + '"' + "DEPOSITER NAME" + '"' + " like '%" + key.ToUpper() + "%' or to_char(" + '"' + "DATE" + '"' + ",'mm/dd/yy')" + " like '%" + key.ToUpper() + "%' order by " + '"' + "DEPOSIT NO" + '"';
            
            DataTable dt = new DataTable();
           try
           {
                OleDbDataAdapter user = new OleDbDataAdapter(query, con);
                user.Fill(dt);
           }
           catch (Exception)
            {
            }
            con.Close();

            return dt;
        }
        public DataTable getAccountInfoTable()
        {
            con.Open();
            string query = "select * from ACCOUNT_INFO ";

            OleDbDataAdapter user = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();

            user.Fill(dt);
            con.Close();

            return dt;
        }
        public DataTable getClientInfoTable()
        {
            con.Open();
            string query = "select * from CLIENT_INFO ";

            OleDbDataAdapter user = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();

            user.Fill(dt);
            con.Close();

            return dt;
        }
        public DataTable searchAccountTableInfo(string key)
        {
            con.Open();
            string query = "select * from ACCOUNT_INFO where to_char(ACC_NO) like '%" + key + "%'  or " + '"' + "NAME" + '"' + " like '%" + key.ToUpper() + "%' order by cl_id";
            DataTable dt = new DataTable();

            try
            {
                OleDbDataAdapter user = new OleDbDataAdapter(query, con);
                user.Fill(dt);
            }
            catch (Exception)
            {
            }
            con.Close();

            return dt;
        }
        public DataTable searchClientTableInfo(string key)
        {
            con.Open();
            string query = "select * from ClIENT_INFO where to_char(CL_CONTACT) like '%" + key + "%'  or " + '"' + "NAME" + '"' + " like '%" + key.ToUpper() + "%' or national_id"+" like '%"+key.ToUpper()+"%' order by cl_id";
            DataTable dt = new DataTable();

            try
            {
                OleDbDataAdapter user = new OleDbDataAdapter(query, con);
                user.Fill(dt);
            }
            catch (Exception)
            {

            }
            con.Close();

            return dt;
        }

        public void insertIntoTransferTable(string accfrom,string accto,string bid,string amnt,string tdate)
        {
            con.Open();
            OleDbCommand cmd = new OleDbCommand("transferMoney", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("accfrom", OleDbType.Numeric).Value = accfrom;
            cmd.Parameters.Add("accto", OleDbType.Numeric).Value = accto;
            cmd.Parameters.Add("bid", OleDbType.Numeric).Value = bid;
            cmd.Parameters.Add("amnt", OleDbType.Numeric).Value = amnt;
            cmd.Parameters.Add("tdate", OleDbType.Date).Value = tdate;

            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            con.Close();

        }
        public DataTable getTransferTable()
        {
            con.Open();
            string query = "select * from TRANSFER order by t_no";

            OleDbDataAdapter user = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();

            user.Fill(dt);
            con.Close();

            return dt;
        }
        public DataTable searchTransferTable(string key)
        {
            con.Open();
            string query = "select * from Transfer where acc_no_from like '%"+key+"%' or acc_no_to like '%"+key+"%' order by t_no";

            DataTable dt = new DataTable();
            try
            {
                OleDbDataAdapter user = new OleDbDataAdapter(query, con);
                user.Fill(dt);
            }
            catch (Exception)
            {
               
            }
            con.Close();

            return dt;
        }
        public void updateTransferTable(int upno,string acc_from,string acc_to,string upTamount,string date,int upamount)
        {
            string query = "update transfer set acc_no_from=" + acc_from + ",acc_no_to=" + acc_to + ",amount=" + upTamount + ",T_date='" + date + "'where T_no=" + upno;
            con.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            cmd.CommandText = query;
            cmd.ExecuteNonQuery();
            con.Close();

            updateAccountBalance(acc_from, -upamount);

            updateAccountBalance(acc_to, upamount);

        }
        public bool isPaymentIdValid(string pid)
        {
            con.Open();
            string query = "select * from loan where loan_id=" + pid;

            OleDbDataAdapter user = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();
            user.Fill(dt);
            int i = dt.Rows.Count;
            con.Close();

            if (i == 1) { return true; }
            else
                return false;
        }

        public void insertIntoPaymentTable(string loanid,string bid,string pamount,string pdate,string name)
        {

            con.Open();
            OleDbCommand cmd = new OleDbCommand("addPayment", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("loanid", OleDbType.Numeric).Value = loanid;
            cmd.Parameters.Add("bid", OleDbType.Numeric).Value = bid;
            cmd.Parameters.Add("amnt", OleDbType.Numeric).Value = pamount;
            cmd.Parameters.Add("pdate", OleDbType.Date).Value = pdate;
            cmd.Parameters.Add("name", OleDbType.VarChar).Value = name;

            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public DataTable getLoanInfo()
        {
            con.Open();
            string query = "select * from loan_info order by p_no";
            DataTable dt = new DataTable();
            try
            {
                OleDbDataAdapter user = new OleDbDataAdapter(query, con);
                user.Fill(dt);
            
            }
            catch(Exception)
            {

            }

            con.Close();

            return dt;
        }
        public void createNewCurrentAccount(string nam,string nid,string add ,string cont,string acctype ,string bal)
        {

            con.Open();
            OleDbCommand cmd = new OleDbCommand("newAccountCU", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("nam", OleDbType.VarChar).Value = nam;
            cmd.Parameters.Add("nid", OleDbType.Numeric).Value = nid;
            cmd.Parameters.Add("add", OleDbType.VarChar).Value = add;
            cmd.Parameters.Add("con", OleDbType.Numeric).Value = cont;
            cmd.Parameters.Add("acctype", OleDbType.VarChar).Value = acctype;
            cmd.Parameters.Add("bal", OleDbType.Numeric).Value = bal;
            cmd.Parameters.Add("bid", OleDbType.VarChar).Value = Employee.e.B_id;
            cmd.Parameters.Add("eid", OleDbType.VarChar).Value = Employee.e.E_id;


            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void createNewFixAccount(string nam, string nid, string add, string cont, string acctype, string bal)
        {

            con.Open();
            OleDbCommand cmd = new OleDbCommand("newAccountFI", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("nam", OleDbType.VarChar).Value = nam;
            cmd.Parameters.Add("nid", OleDbType.Numeric).Value = nid;
            cmd.Parameters.Add("add", OleDbType.VarChar).Value = add;
            cmd.Parameters.Add("con", OleDbType.Numeric).Value = cont;
            cmd.Parameters.Add("acctype", OleDbType.VarChar).Value = acctype;
            cmd.Parameters.Add("bal", OleDbType.Numeric).Value = bal;
            cmd.Parameters.Add("bid", OleDbType.VarChar).Value = Employee.e.B_id;
            cmd.Parameters.Add("eid", OleDbType.VarChar).Value = Employee.e.E_id;


            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void createNewCorporateAccount(string nam, string rep, string add, string cont, string acctype, string bal)
        {

            con.Open();
            OleDbCommand cmd = new OleDbCommand("newAccountCo", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("comnam", OleDbType.VarChar).Value = nam;
            cmd.Parameters.Add("rep", OleDbType.VarChar).Value = rep;
            cmd.Parameters.Add("add", OleDbType.VarChar).Value = add;
            cmd.Parameters.Add("con", OleDbType.Numeric).Value = cont;
            cmd.Parameters.Add("acctype", OleDbType.VarChar).Value = acctype;
            cmd.Parameters.Add("bal", OleDbType.Numeric).Value = bal;
            cmd.Parameters.Add("bid", OleDbType.VarChar).Value = Employee.e.B_id;
            cmd.Parameters.Add("eid", OleDbType.VarChar).Value = Employee.e.E_id;


            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void insertWithdraCheque(string amount, string accno, string chqno)
        {

            con.Open();
            OleDbCommand cmd = new OleDbCommand("withdrawbycheque", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("amnt", OleDbType.Numeric).Value = amount;
            cmd.Parameters.Add("accno", OleDbType.Numeric).Value = accno;
            cmd.Parameters.Add("bid", OleDbType.Numeric).Value = Employee.e.B_id;
            cmd.Parameters.Add("chqno", OleDbType.Numeric).Value = chqno;
            cmd.Parameters.Add("issuedby", OleDbType.VarChar).Value = Employee.e.E_id;

            cmd.Parameters.Add("result",OleDbType.VarChar, 1);
            cmd.Parameters["result"].Direction = ParameterDirection.Output;
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            con.Close();



            if (cmd.Parameters["result"].Value.ToString().Equals("S"))
            {
                System.Windows.MessageBox.Show("SUCCESSFULLY ISSUED ", "", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
            }
            else
                System.Windows.MessageBox.Show("FAILED NOT ENOUGH BALANCE !!!", "ERROR",System.Windows.MessageBoxButton.OK,System.Windows.MessageBoxImage.Hand);

        }

        public DataTable getChequeWithdrawTable()
        {
            con.Open();
            string query = "select * from chq_withdraw";

            OleDbDataAdapter user = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();

            user.Fill(dt);
            con.Close();

            return dt;
        }
        public DataTable searchChequeWithdrawTable(string key)
        {
            con.Open();
            string query = "select * from chq_withdraw where to_char(w_no) like '%" + key + "%' or amount like '%" + key + "%' or acc_no like '%" + key + "%' or " + '"' + "CHEQUE NO" + '"' + " like '%" + key + "%' or issued_by like '%" + key + "%'";
            DataTable dt = new DataTable();
            try
            {
                OleDbDataAdapter user = new OleDbDataAdapter(query, con);
                
                user.Fill(dt);
            }
            catch(Exception) 
            {
            }
            con.Close();

            return dt;
        }

    }
}
