﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BANKContext;
namespace BankTransection
{
    public partial class Profile : Form
    {
        public EMPLOYEET emp;
        public Profile(EMPLOYEET e)
        {
            this.emp = e;
            InitializeComponent();
        }

        private void Profile_Load(object sender, EventArgs e)
        {
            if(emp!=null)
            {
                pictureBox1.ImageLocation = emp.PHOTO;
                labelName.Text = emp.ENAME;
               
                if (emp.HIREDATE != null)
                {
                    labelId.Text = Convert.ToDateTime(emp.HIREDATE.ToString()).ToString("yy") + "-" + emp.EID.ToString() + "-" + emp.DID;
                    labelJD.Text = Convert.ToDateTime(emp.HIREDATE.ToString()).ToString("dd-MMMM-yyyy");
                }
                //labelId.Text = Employee.e.id_full;
                labelMail.Text = emp.MAIL;
                labelSal.Text = emp.SALARY.ToString()+" BDT";
                labelJob.Text = emp.JOB;
                
            }
        }

        private void Profile_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Dispose(true);
        }

       
    }
}
