﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankTransection
{
    public partial class Transfer : Form
    {
        
        public Transfer()
        {
            InitializeComponent();
            
        }
        public void reloadTransferTable()
        {
            dataGridTransfer.DataSource = new OdbDataProvider().getTransferTable();
            dataGridTransfer.FirstDisplayedScrollingRowIndex = dataGridTransfer.RowCount - 1;
            lableSum.Text = "";
        }
        private void BtnInsert_Click(object sender, EventArgs e)
        {
            String Date = date.Value.ToString("dd-MMM-yy");
            int accno, amnt, rec;

            if (int.TryParse(acc_from.Text, out accno) && int.TryParse(amount.Text, out amnt) && int.TryParse(acc_to.Text, out rec) && new OdbDataProvider().isAccountValid(acc_to.Text) && new OdbDataProvider().isAccountValid(acc_from.Text))
            {
                if (amnt >= 500)
                {

                    new OdbDataProvider().insertIntoTransferTable(acc_from.Text,acc_to.Text,b_id.Text,amount.Text,Date);

                    reloadTransferTable();
                }
                else MessageBox.Show("INVALID ACCOUNT OR AMOUNT", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show("INVALID ACCOUNT OR AMOUNT", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void Transfer_Load(object sender, EventArgs e)
        {
            reloadTransferTable();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            reloadTransferTable();
            acc_from.Clear();
            acc_to.Clear();
            amount.Clear();
        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        {
            dataGridTransfer.DataSource = new OdbDataProvider().searchTransferTable(searchBox.Text);
        }

        private void back_Click(object sender, EventArgs e)
        {
            //HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
            this.Dispose(true);
        }

        private void Transfer_FormClosed(object sender, FormClosedEventArgs e)
        {
           // HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
            this.Dispose(true);
        }

        private void searchClear_Click(object sender, EventArgs e)
        {
            searchBox.Clear();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
           
            if (dataGridTransfer.SelectedRows.Count > 0 && dataGridTransfer.SelectedRows[0].Cells[0].Value != null)
            {
                int updateno = Convert.ToInt32(dataGridTransfer.SelectedRows[0].Cells[0].Value.ToString());
                string acc_from = dataGridTransfer.SelectedRows[0].Cells[1].Value.ToString();
                string acc_to = dataGridTransfer.SelectedRows[0].Cells[2].Value.ToString();
                string Amnt = dataGridTransfer.SelectedRows[0].Cells[4].Value.ToString();
                DateTime Dte = Convert.ToDateTime(dataGridTransfer.SelectedRows[0].Cells[5].Value.ToString());

                updateTransfer upt = new updateTransfer();

                upt.previousAmnt = int.Parse(Amnt);
                upt.upno = updateno;
                upt.acc_from.Text = acc_from;
                upt.acc_to.Text = acc_to;
                upt.accfrom = acc_from;
                upt.accto = acc_to;
                upt.amount.Text = Amnt;
                upt.date.Value = Dte;

                upt.acc_from.Enabled = false;
                upt.acc_to.Enabled = false;

                upt.ShowDialog();
                reloadTransferTable();
            }
            else MessageBox.Show("SELECT A ROW TO UPDATE", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        private void buttonSum_Click(object sender, EventArgs e)
        {
            int sum = 0;
            int val = 0;
            if (dataGridTransfer.SelectedRows.Count > 0)
            {
                try
                {
                    for (int i = 0; i < dataGridTransfer.SelectedRows.Count; i++)
                    {
                        if (dataGridTransfer.SelectedRows[i].Cells[4].Value != null)
                            if (int.TryParse(dataGridTransfer.SelectedRows[i].Cells[4].Value.ToString(), out val))
                            {
                                sum = sum + val;
                            }
                    }

                }
                catch (Exception) { }
            }
            lableSum.Text = sum.ToString() + " BDT";
        }

        
    }
}
