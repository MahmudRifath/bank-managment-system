﻿namespace BankTransection
{
    partial class Update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.datetime = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.amount = new System.Windows.Forms.TextBox();
            this.d_name = new System.Windows.Forms.TextBox();
            this.acc_no = new System.Windows.Forms.TextBox();
            this.done = new System.Windows.Forms.Button();
            this.cancle = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // datetime
            // 
            this.datetime.CustomFormat = "dd-MMM-yy";
            this.datetime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datetime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datetime.Location = new System.Drawing.Point(366, 25);
            this.datetime.Name = "datetime";
            this.datetime.Size = new System.Drawing.Size(125, 26);
            this.datetime.TabIndex = 20;
            this.datetime.Value = new System.DateTime(2017, 7, 29, 0, 0, 0, 0);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "AMOUNT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "ACCOUNT NO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "DEPOSITER NAME";
            // 
            // amount
            // 
            this.amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amount.Location = new System.Drawing.Point(126, 129);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(208, 29);
            this.amount.TabIndex = 16;
            // 
            // d_name
            // 
            this.d_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d_name.Location = new System.Drawing.Point(126, 77);
            this.d_name.Name = "d_name";
            this.d_name.Size = new System.Drawing.Size(208, 29);
            this.d_name.TabIndex = 15;
            // 
            // acc_no
            // 
            this.acc_no.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acc_no.Location = new System.Drawing.Point(126, 25);
            this.acc_no.Name = "acc_no";
            this.acc_no.Size = new System.Drawing.Size(208, 29);
            this.acc_no.TabIndex = 14;
            // 
            // done
            // 
            this.done.BackColor = System.Drawing.SystemColors.Highlight;
            this.done.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.done.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.done.Location = new System.Drawing.Point(160, 185);
            this.done.Name = "done";
            this.done.Size = new System.Drawing.Size(160, 32);
            this.done.TabIndex = 21;
            this.done.Text = "DONE";
            this.done.UseVisualStyleBackColor = false;
            this.done.Click += new System.EventHandler(this.done_Click);
            // 
            // cancle
            // 
            this.cancle.BackColor = System.Drawing.Color.Red;
            this.cancle.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancle.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancle.Location = new System.Drawing.Point(433, 188);
            this.cancle.Name = "cancle";
            this.cancle.Size = new System.Drawing.Size(99, 29);
            this.cancle.TabIndex = 22;
            this.cancle.Text = "CANCLE";
            this.cancle.UseVisualStyleBackColor = false;
            this.cancle.Click += new System.EventHandler(this.cancle_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.datetime);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.amount);
            this.groupBox1.Controls.Add(this.d_name);
            this.groupBox1.Controls.Add(this.acc_no);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(520, 171);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "UPDATE VALUES";
            // 
            // Update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(542, 226);
            this.Controls.Add(this.done);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cancle);
            this.Location = new System.Drawing.Point(250, 250);
            this.Name = "Update";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Update_FormClosed);
            this.Load += new System.EventHandler(this.Update_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DateTimePicker datetime;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox amount;
        public System.Windows.Forms.TextBox d_name;
        public System.Windows.Forms.TextBox acc_no;
        private System.Windows.Forms.Button done;
        private System.Windows.Forms.Button cancle;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}