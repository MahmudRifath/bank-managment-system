﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankTransection
{
    public partial class Update : Form
    {
        public int dno;
        public int previousAmnt;
        
        public Update()
        {
            InitializeComponent();
        }
        public void Error(string msg)
        {
            MessageBox.Show(msg,"ERROR !!!",MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void Update_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Dispose(true);
        }

        private void cancle_Click(object sender, EventArgs e)
        {
            this.Dispose(true);
        }

        private void done_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("UPDATE INFORMATION", "UPDATE INFO", MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                int amnt;
                if (int.TryParse(amount.Text, out amnt) && d_name.Text.Length > 3)
                {

                    if (amnt >= 500)
                    {
                        amnt -= this.previousAmnt;
                        new OdbDataProvider().updateDepositTable(acc_no.Text, d_name.Text.ToUpper(), amnt, datetime.Value.ToString("dd-MMM-yy"), dno, int.Parse(amount.Text));
                        this.Dispose(true);
                    }
                    else Error("INVALID AMOUNT OR NAME");
                }
                else Error("INVALID AMOUNT OR NAME");
            }
            else if (dialogResult == DialogResult.No)
            {
                
            }
            
            
        }

        private void Update_Load(object sender, EventArgs e)
        {

        }

    }
}
