﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankTransection
{
    public partial class W_Cheque : Form
    {
        public W_Cheque()
        {
            InitializeComponent();
        }

        public void reloadWCTable()
        {
            dataGridCWithdraw.DataSource = new OdbDataProvider().getChequeWithdrawTable();
            dataGridCWithdraw.FirstDisplayedScrollingRowIndex = dataGridCWithdraw.RowCount - 1;

            lableSum.Text = "";
        }
        public void Error()
        {
            MessageBox.Show("INVALID ACCOUNT OR AMOUNT", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void BtnInsert_Click(object sender, EventArgs e)
        {
            int amnt, acc, cno;
            if (int.TryParse(amount.Text, out amnt) && int.TryParse(acc_no.Text, out acc) && int.TryParse(chqno.Text, out cno) && new OdbDataProvider().isAccountValid(acc_no.Text))
            {

                if (amnt >= 100)
                {
                    new OdbDataProvider().insertWithdraCheque(amount.Text, acc_no.Text, chqno.Text);
                    reloadWCTable();
                }
                else Error();
            }
            else Error(); 
            }

        private void W_Cheque_Load(object sender, EventArgs e)
        {
            reloadWCTable();
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            reloadWCTable();
        }

        private void W_Cheque_FormClosed(object sender, FormClosedEventArgs e)
        {
            //HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
            this.Dispose(true);
        }

        private void back_Click(object sender, EventArgs e)
        {
            //HomePage.hp.Show();
            HomePage.hp.WindowState = FormWindowState.Maximized;
            HomePage.hp.BringToFront();
            this.Dispose(true);
        }

        private void searchClear_Click(object sender, EventArgs e)
        {
            searchBox.Clear();
            reloadWCTable();
        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        {
            dataGridCWithdraw.DataSource = new OdbDataProvider().searchChequeWithdrawTable(searchBox.Text.ToUpper());
        }

        private void buttonSum_Click(object sender, EventArgs e)
        {
            int sum = 0;
            int val = 0;
            if (dataGridCWithdraw.SelectedRows.Count > 0)
            {
                try
                {
                    for (int i = 0; i < dataGridCWithdraw.SelectedRows.Count; i++)
                    {
                        if (dataGridCWithdraw.SelectedRows[i].Cells[2].Value != null)
                            if (int.TryParse(dataGridCWithdraw.SelectedRows[i].Cells[2].Value.ToString(), out val))
                            {
                                sum = sum + val;
                            }
                    }

                }
                catch (Exception) { }
            }
            lableSum.Text = sum.ToString() + " BDT";
        }
    }
}
