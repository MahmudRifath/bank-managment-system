﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankTransection
{
    public partial class updateTransfer : Form
    {
        public int upno;
        public int previousAmnt;
        public string accfrom;
        public string accto;
        public updateTransfer()
        {
            InitializeComponent();
        }

        private void BtnInsert_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("ARE YOU SURE", "UPDATE INFO", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                int amnt;
                if (int.TryParse(amount.Text, out amnt))
                {
                    
                    if (amnt >= 500)
                    {
                        amnt -= this.previousAmnt;
                        new OdbDataProvider().updateTransferTable(upno, acc_from.Text, acc_to.Text, amount.Text, date.Value.ToString("dd-MMM-yy"), amnt);
                        this.Dispose(true);
                    }
                    else MessageBox.Show("INVALID AMOUNT", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (dialogResult == DialogResult.No)
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose(true);
        }
    }
}
