--------------------------------------------------------
--  File created - Wednesday-March-13-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence ACCNO
--------------------------------------------------------

   CREATE SEQUENCE  "BANK"."ACCNO"  MINVALUE 1 MAXVALUE 100000000 INCREMENT BY 125 START WITH 6000875 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence CLNO
--------------------------------------------------------

   CREATE SEQUENCE  "BANK"."CLNO"  MINVALUE 1 MAXVALUE 1000000 INCREMENT BY 1 START WITH 13 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence DCARD
--------------------------------------------------------

   CREATE SEQUENCE  "BANK"."DCARD"  MINVALUE 1 MAXVALUE 1000000 INCREMENT BY 1 START WITH 4329 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence DEPOSIT_NO
--------------------------------------------------------

   CREATE SEQUENCE  "BANK"."DEPOSIT_NO"  MINVALUE 1 MAXVALUE 1000000 INCREMENT BY 1 START WITH 44 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence PAYMENTNO
--------------------------------------------------------

   CREATE SEQUENCE  "BANK"."PAYMENTNO"  MINVALUE 1 MAXVALUE 1000000 INCREMENT BY 1 START WITH 6 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TNO
--------------------------------------------------------

   CREATE SEQUENCE  "BANK"."TNO"  MINVALUE 1 MAXVALUE 1000000 INCREMENT BY 1 START WITH 11 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence WNO
--------------------------------------------------------

   CREATE SEQUENCE  "BANK"."WNO"  MINVALUE 1 MAXVALUE 1000000 INCREMENT BY 1 START WITH 13 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Table ACCOUNT
--------------------------------------------------------

  CREATE TABLE "BANK"."ACCOUNT" 
   (	"ACC_NO" VARCHAR2(50 BYTE), 
	"ACC_TYPE" VARCHAR2(50 BYTE), 
	"DEBITCARD_NO" VARCHAR2(50 BYTE), 
	"CREDITCARD_NO" VARCHAR2(50 BYTE), 
	"BALANCE" NUMBER(15,0), 
	"CL_ID" NUMBER(4,0), 
	"B_ID" NUMBER, 
	"E_ID" NUMBER(6,0), 
	"OPENINGDATE" DATE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table APPROVED_LOAN
--------------------------------------------------------

  CREATE TABLE "BANK"."APPROVED_LOAN" 
   (	"LOAN_NO" NUMBER(4,0), 
	"APPROVER_ID" NUMBER(4,0), 
	"ACC_NO" VARCHAR2(50 BYTE), 
	"APP_DATE" DATE, 
	"LOAN_ID" VARCHAR2(50 BYTE), 
	"APPROVED_ID" NUMBER
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table APPROVED_STATUS
--------------------------------------------------------

  CREATE TABLE "BANK"."APPROVED_STATUS" 
   (	"APPROVED_ID" NUMBER, 
	"STATUS" VARCHAR2(50 BYTE), 
	"A_DATE" DATE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table ATM
--------------------------------------------------------

  CREATE TABLE "BANK"."ATM" 
   (	"ATM_ID" VARCHAR2(50 BYTE), 
	"B_ID" NUMBER, 
	"BALANCE" NUMBER(6,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table BRANCH
--------------------------------------------------------

  CREATE TABLE "BANK"."BRANCH" 
   (	"B_ID" NUMBER, 
	"B_NAME" VARCHAR2(50 BYTE), 
	"LOCATION" VARCHAR2(50 BYTE), 
	"TOTALMONEY" NUMBER(15,2)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table CLIENT
--------------------------------------------------------

  CREATE TABLE "BANK"."CLIENT" 
   (	"CL_ID" NUMBER(4,0), 
	"ADDRESS" VARCHAR2(50 BYTE), 
	"CL_CONTACT" VARCHAR2(50 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table CORPORATE
--------------------------------------------------------

  CREATE TABLE "BANK"."CORPORATE" 
   (	"CL_ID" NUMBER(4,0), 
	"COMPANY_NAME" VARCHAR2(50 BYTE), 
	"REPRESENTATOR_NAME" VARCHAR2(50 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table CREDITCARD
--------------------------------------------------------

  CREATE TABLE "BANK"."CREDITCARD" 
   (	"CREDITCARD_NO" VARCHAR2(50 BYTE), 
	"LIMIT" NUMBER(6,0), 
	"EXP_DATE" DATE, 
	"PIN" NUMBER(5,0), 
	"LOAN_ID" VARCHAR2(50 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table DEBITCARD
--------------------------------------------------------

  CREATE TABLE "BANK"."DEBITCARD" 
   (	"DEBITCARD_NO" VARCHAR2(50 BYTE), 
	"VALIDDATE" DATE, 
	"PIN" NUMBER(5,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table DEPARTMENT
--------------------------------------------------------

  CREATE TABLE "BANK"."DEPARTMENT" 
   (	"D_ID" NUMBER(6,0), 
	"D_NAME" VARCHAR2(50 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table DEPOSIT
--------------------------------------------------------

  CREATE TABLE "BANK"."DEPOSIT" 
   (	"D_NO" NUMBER(4,0), 
	"D_NAME" VARCHAR2(50 BYTE), 
	"D_DATE" DATE, 
	"B_ID" NUMBER, 
	"ACC_NO" VARCHAR2(50 BYTE), 
	"AMOUNT" NUMBER(7,0), 
	"RECEIVER" NUMBER(4,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table DEPOSITBYMONTH
--------------------------------------------------------

  CREATE TABLE "BANK"."DEPOSITBYMONTH" 
   (	"MONTH" VARCHAR2(5 CHAR), 
	"AMOUNT" NUMBER
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table DEPOSIT_UPDATE_LOG
--------------------------------------------------------

  CREATE TABLE "BANK"."DEPOSIT_UPDATE_LOG" 
   (	"D_NO" NUMBER(6,0), 
	"OLD_AMOUNT" NUMBER(9,0), 
	"NEW_AMOUNT" NUMBER(9,0), 
	"UPDATE_DATE" DATE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table EMPLOYEE
--------------------------------------------------------

  CREATE TABLE "BANK"."EMPLOYEE" 
   (	"E_ID" NUMBER(6,0), 
	"E_NAME" VARCHAR2(50 BYTE), 
	"SALARY" NUMBER(6,0), 
	"JOB" VARCHAR2(50 BYTE), 
	"B_ID" NUMBER, 
	"D_ID" NUMBER(6,0), 
	"PHOTO" VARCHAR2(4000 BYTE), 
	"MAIL" VARCHAR2(4000 BYTE), 
	"HIREDATE" DATE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table LOAN
--------------------------------------------------------

  CREATE TABLE "BANK"."LOAN" 
   (	"LOAN_ID" VARCHAR2(50 CHAR), 
	"INTEREST_RATE" VARCHAR2(50 CHAR), 
	"LOAN_ON" VARCHAR2(50 CHAR), 
	"DURATION_MONTH" NUMBER(4,0), 
	"AMOUNT" NUMBER(7,0), 
	"ACCOUNT" VARCHAR2(50 CHAR), 
	"TO_BEPAID" NUMBER(7,0), 
	"APPROVER" NUMBER(6,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table LOGIN
--------------------------------------------------------

  CREATE TABLE "BANK"."LOGIN" 
   (	"E_ID" NUMBER(6,0), 
	"U_ID" VARCHAR2(50 BYTE), 
	"PASSWORD" VARCHAR2(50 BYTE), 
	"STATUS" VARCHAR2(50 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table ONNET
--------------------------------------------------------

  CREATE TABLE "BANK"."ONNET" 
   (	"REQ_NO" NUMBER(4,0), 
	"CARD_NO" VARCHAR2(50 BYTE), 
	"CARD_TYPE" VARCHAR2(50 BYTE), 
	"AMOUNT" NUMBER(6,0), 
	"STATUS" VARCHAR2(50 BYTE), 
	"REQ_DATE" DATE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table PAYMENT
--------------------------------------------------------

  CREATE TABLE "BANK"."PAYMENT" 
   (	"P_NO" NUMBER(4,0), 
	"LOAN_ID" VARCHAR2(50 BYTE), 
	"B_ID" NUMBER, 
	"P_AMOUNT" NUMBER(6,0), 
	"P_DATE" DATE, 
	"NAME" VARCHAR2(50 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table PERSONAL
--------------------------------------------------------

  CREATE TABLE "BANK"."PERSONAL" 
   (	"CL_ID" NUMBER(4,0), 
	"NAME" VARCHAR2(50 BYTE), 
	"NATIONAL_ID" VARCHAR2(50 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table SALARY_LOG
--------------------------------------------------------

  CREATE TABLE "BANK"."SALARY_LOG" 
   (	"E_ID" NUMBER(6,0), 
	"OLD_SALARY" NUMBER(9,0), 
	"NEW_SALARY" NUMBER(9,0), 
	"UPDATE_DATE" DATE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table TRANSFER
--------------------------------------------------------

  CREATE TABLE "BANK"."TRANSFER" 
   (	"T_NO" NUMBER(4,0), 
	"ACC_NO_FROM" VARCHAR2(50 BYTE), 
	"ACC_NO_TO" VARCHAR2(50 BYTE), 
	"B_ID" NUMBER, 
	"AMOUNT" NUMBER(6,0), 
	"T_DATE" DATE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table TRANSFERBYMONTH
--------------------------------------------------------

  CREATE TABLE "BANK"."TRANSFERBYMONTH" 
   (	"MONTH" VARCHAR2(5 CHAR), 
	"AMOUNT" NUMBER
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table TRANSFER_UPDATE_LOG
--------------------------------------------------------

  CREATE TABLE "BANK"."TRANSFER_UPDATE_LOG" 
   (	"T_NO" NUMBER(6,0), 
	"OLD_AMOUNT" NUMBER(9,0), 
	"NEW_AMOUNT" NUMBER(9,0), 
	"UPDATE_DATE" DATE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table WITHDRAW
--------------------------------------------------------

  CREATE TABLE "BANK"."WITHDRAW" 
   (	"W_NO" NUMBER(4,0), 
	"W_TYPE" VARCHAR2(50 BYTE), 
	"W_DATE" DATE, 
	"AMOUNT" NUMBER(5,0), 
	"ACC_NO" VARCHAR2(50 BYTE), 
	"B_ID" NUMBER
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table WITHDRAWBYMONTH
--------------------------------------------------------

  CREATE TABLE "BANK"."WITHDRAWBYMONTH" 
   (	"MONTH" VARCHAR2(5 CHAR), 
	"AMOUNT" NUMBER
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table W_ATM
--------------------------------------------------------

  CREATE TABLE "BANK"."W_ATM" 
   (	"W_NO" NUMBER(4,0), 
	"ATM_ID" VARCHAR2(50 BYTE), 
	"CARD_TYPE" VARCHAR2(50 BYTE), 
	"CARD_NO" VARCHAR2(50 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table W_CHEQUE
--------------------------------------------------------

  CREATE TABLE "BANK"."W_CHEQUE" 
   (	"W_NO" NUMBER(4,0), 
	"CHK_NO" VARCHAR2(50 BYTE), 
	"ACC_NO" VARCHAR2(50 BYTE), 
	"ISSUED_BY" VARCHAR2(50 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for View ACCOUNT_INFO
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "BANK"."ACCOUNT_INFO" ("CL_ID", "B_ID", "ACC_NO", "ACC_TYPE", "BALANCE", "NAME", "CL_CONTACT", "ADDRESS", "NATIONAL_ID", "DEBITCARD_NO", "CREDITCARD_NO", "COMPANY_NAME", "REPRESENTATOR_NAME") AS 
  SELECT CL_ID,B_ID,ACC_NO,ACC_TYPE,BALANCE,NAME,CL_CONTACT,ADDRESS,NATIONAL_ID,DEBITCARD_NO,CREDITCARD_NO,COMPANY_NAME,REPRESENTATOR_NAME FROM ACCOUNT 
JOIN CLIENT USING(CL_ID) LEFT JOIN PERSONAL USING(CL_ID) LEFT JOIN CORPORATE USING(CL_ID) ORDER BY CL_ID
;
--------------------------------------------------------
--  DDL for View ATM_WITHDRAW
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "BANK"."ATM_WITHDRAW" ("W_NO", "W_TYPE", "W_DATE", "AMOUNT", "ACC_NO", "B_ID", "ATM_ID", "CARD_TYPE", "CARD_NO") AS 
  SELECT * FROM WITHDRAW JOIN W_ATM USING(W_NO)
;
--------------------------------------------------------
--  DDL for View CHQ_WITHDRAW
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "BANK"."CHQ_WITHDRAW" ("W_NO", "W_TYPE", "AMOUNT", "ACC_NO", "B_ID", "CHEQUE NO", "ISSUED_BY") AS 
  SELECT w_no,w_type,amount,withdraw.acc_no,b_id,chk_no as "CHEQUE NO",ISSUED_BY FROM WITHDRAW JOIN W_CHEQUE USING(W_NO) order by w_no
;
--------------------------------------------------------
--  DDL for View CLIENT_INFO
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "BANK"."CLIENT_INFO" ("CL_ID", "ADDRESS", "CL_CONTACT", "NAME", "NATIONAL_ID", "COMPANY_NAME", "REPRESENTATOR_NAME") AS 
  SELECT * FROM CLIENT LEFT JOIN PERSONAL USING (CL_ID) LEFT JOIN CORPORATE USING (CL_ID)
ORDER BY CL_ID
;
--------------------------------------------------------
--  DDL for View DEPOSIT_STATUS
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "BANK"."DEPOSIT_STATUS" ("DEPOSIT NO", "DEPOSITER NAME", "DATE", "BRUNCH", "ACCOUNT", "AMOUNT", "RECEIVER NAME") AS 
  select d.D_NO AS "DEPOSIT NO",d.d_NAME AS "DEPOSITER NAME",d.d_date AS "DATE" ,b.b_name AS BRUNCH ,d.acc_no as ACCOUNT ,d.amount,e.e_name as 
"RECEIVER NAME" from deposit d,employee e ,branch b where d.receiver=e.e_id and b.b_id=d.B_id
;
--------------------------------------------------------
--  DDL for View EMP_INFO
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "BANK"."EMP_INFO" ("E_ID", "E_NAME", "JOB", "SALARY", "B_ID", "D_ID", "MAIL", "HIREDATE", "EXP_MONTH", "STATUS") AS 
  select employee.E_ID,employee.E_NAME,employee.JOB,employee.SALARY,employee.B_ID,employee.D_ID,employee.MAIL,employee.HIREDATE, ROUND(MONTHS_BETWEEN(sysdate,HIREDATE),2) as EXP_MONTH ,LOGIN.STATUS from employee , LOGIN where employee.E_ID=LOGIN.E_ID
;
--------------------------------------------------------
--  DDL for View LOAN_INFO
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "BANK"."LOAN_INFO" ("P_NO", "LOAN_ID", "LOAN_FOR", "ACCOUNT", "B_ID", "P_AMOUNT", "TO_BEPAID", "P_DATE", "NAME") AS 
  select p.p_no,l.loan_id,l.REQUISITE as Loan_For,l.account,p.b_id,p.p_amount,l.to_bePAID,p.p_date,p.name from loan l,payment p where l.loan_id=p.loan_id
;
--------------------------------------------------------
--  DDL for View LOAN_TAKEN
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "BANK"."LOAN_TAKEN" ("ACC_NO", "NAME", "COMPANY_NAME", "REPRESENTATOR_NAME") AS 
  SELECT A.ACC_NO, NAME, COMPANY_NAME, REPRESENTATOR_NAME FROM ACCOUNT A JOIN APPROVED_LOAN L ON (A.ACC_NO=L.ACC_NO) 
JOIN CLIENT ON (A.CL_ID=CLIENT.CL_ID) LEFT JOIN PERSONAL ON (CLIENT.CL_ID=PERSONAL.CL_ID) LEFT JOIN CORPORATE ON(CLIENT.CL_ID=CORPORATE.CL_ID)
;
--------------------------------------------------------
--  DDL for View SAL_JOB_DEPT
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "BANK"."SAL_JOB_DEPT" ("JOB", "DEPT10", "DEPT 20", "DEPT 30", "DEPT 40", "TOTAL") AS 
  SELECT JOB ,SUM(DECODE(D_ID,10,SALARY,0)) "DEPT10",SUM(DECODE(D_ID,20,SALARY,0)) "DEPT 20",SUM(DECODE(D_ID,30,SALARY,0)) 
"DEPT 30",SUM(DECODE(D_ID,40,SALARY,0)) "DEPT 40",SUM(SALARY) "TOTAL" FROM EMPLOYEE GROUP BY JOB
;
REM INSERTING into BANK.ACCOUNT
SET DEFINE OFF;
Insert into BANK.ACCOUNT (ACC_NO,ACC_TYPE,DEBITCARD_NO,CREDITCARD_NO,BALANCE,CL_ID,B_ID,E_ID,OPENINGDATE) values ('6000625','CURRENT','4327',null,23000,11,1,10,to_date('12-MAR-19','DD-MON-RR'));
Insert into BANK.ACCOUNT (ACC_NO,ACC_TYPE,DEBITCARD_NO,CREDITCARD_NO,BALANCE,CL_ID,B_ID,E_ID,OPENINGDATE) values ('6000750','CURRENT','4328',null,2000,12,1,10,to_date('12-MAR-19','DD-MON-RR'));
REM INSERTING into BANK.APPROVED_LOAN
SET DEFINE OFF;
REM INSERTING into BANK.APPROVED_STATUS
SET DEFINE OFF;
REM INSERTING into BANK.ATM
SET DEFINE OFF;
REM INSERTING into BANK.BRANCH
SET DEFINE OFF;
Insert into BANK.BRANCH (B_ID,B_NAME,LOCATION,TOTALMONEY) values (1,'AIUB COMMERCIAL BANK ,BANANI BRANCH','KAMAL ATATURK AVENUE , BANANI ROAD-4',500000);
Insert into BANK.BRANCH (B_ID,B_NAME,LOCATION,TOTALMONEY) values (2,'AIUB COMMERCIAL BANK , BASHUDHARA BRANCH','BASHUNDHARA R/A ,BLOCK-A,ROAD-9',500000);
REM INSERTING into BANK.CLIENT
SET DEFINE OFF;
Insert into BANK.CLIENT (CL_ID,ADDRESS,CL_CONTACT) values (11,'bashundhara','1617449246');
Insert into BANK.CLIENT (CL_ID,ADDRESS,CL_CONTACT) values (12,'BASHUNDHARA R\A','1611111111');
Insert into BANK.CLIENT (CL_ID,ADDRESS,CL_CONTACT) values (1,'BASHUNDHARA','01534580001');
REM INSERTING into BANK.CORPORATE
SET DEFINE OFF;
REM INSERTING into BANK.CREDITCARD
SET DEFINE OFF;
REM INSERTING into BANK.DEBITCARD
SET DEFINE OFF;
REM INSERTING into BANK.DEPARTMENT
SET DEFINE OFF;
Insert into BANK.DEPARTMENT (D_ID,D_NAME) values (1,'RIFATH MAHMUD');
Insert into BANK.DEPARTMENT (D_ID,D_NAME) values (10,'account');
REM INSERTING into BANK.DEPOSIT
SET DEFINE OFF;
Insert into BANK.DEPOSIT (D_NO,D_NAME,D_DATE,B_ID,ACC_NO,AMOUNT,RECEIVER) values (41,'MH',to_date('12-MAR-19','DD-MON-RR'),1,'6000625',1500,10);
Insert into BANK.DEPOSIT (D_NO,D_NAME,D_DATE,B_ID,ACC_NO,AMOUNT,RECEIVER) values (42,'TW',to_date('12-MAR-19','DD-MON-RR'),1,'6000625',2000,10);
Insert into BANK.DEPOSIT (D_NO,D_NAME,D_DATE,B_ID,ACC_NO,AMOUNT,RECEIVER) values (43,'ASD',to_date('13-MAR-19','DD-MON-RR'),1,'6000625',20000,10);
REM INSERTING into BANK.DEPOSITBYMONTH
SET DEFINE OFF;
REM INSERTING into BANK.DEPOSIT_UPDATE_LOG
SET DEFINE OFF;
REM INSERTING into BANK.EMPLOYEE
SET DEFINE OFF;
Insert into BANK.EMPLOYEE (E_ID,E_NAME,SALARY,JOB,B_ID,D_ID,PHOTO,MAIL,HIREDATE) values (10,'RIFATH',10000,'MANAGER',1,10,'asdasd','mahmud@gmail.com',to_date('10-JAN-14','DD-MON-RR'));
Insert into BANK.EMPLOYEE (E_ID,E_NAME,SALARY,JOB,B_ID,D_ID,PHOTO,MAIL,HIREDATE) values (11,'MAHMUD',15000,'MANAGER',1,10,'C:\Users\MAHMUD\Desktop\thEVK0ZON6.jpg','mh@gmail.com',to_date('12-MAR-19','DD-MON-RR'));
REM INSERTING into BANK.LOAN
SET DEFINE OFF;
Insert into BANK.LOAN (LOAN_ID,INTEREST_RATE,LOAN_ON,DURATION_MONTH,AMOUNT,ACCOUNT,TO_BEPAID,APPROVER) values ('1','12','gyjgjfj',0,10000,'6000625',1000,10);
Insert into BANK.LOAN (LOAN_ID,INTEREST_RATE,LOAN_ON,DURATION_MONTH,AMOUNT,ACCOUNT,TO_BEPAID,APPROVER) values ('2','0.13','JGFJHGJHV',13,15000,'6000750',16950,10);
REM INSERTING into BANK.LOGIN
SET DEFINE OFF;
Insert into BANK.LOGIN (E_ID,U_ID,PASSWORD,STATUS) values (10,'14-10-10','admin','VALID');
Insert into BANK.LOGIN (E_ID,U_ID,PASSWORD,STATUS) values (11,'19-11-10','test','VALID');
REM INSERTING into BANK.ONNET
SET DEFINE OFF;
REM INSERTING into BANK.PAYMENT
SET DEFINE OFF;
REM INSERTING into BANK.PERSONAL
SET DEFINE OFF;
Insert into BANK.PERSONAL (CL_ID,NAME,NATIONAL_ID) values (11,'MAHMUD','123456789');
Insert into BANK.PERSONAL (CL_ID,NAME,NATIONAL_ID) values (12,'TOWSIF','987654321');
REM INSERTING into BANK.SALARY_LOG
SET DEFINE OFF;
Insert into BANK.SALARY_LOG (E_ID,OLD_SALARY,NEW_SALARY,UPDATE_DATE) values (10,10000,10000,to_date('12-MAR-19','DD-MON-RR'));
REM INSERTING into BANK.TRANSFER
SET DEFINE OFF;
Insert into BANK.TRANSFER (T_NO,ACC_NO_FROM,ACC_NO_TO,B_ID,AMOUNT,T_DATE) values (10,'6000625','6000750',1,1000,to_date('12-MAR-19','DD-MON-RR'));
REM INSERTING into BANK.TRANSFERBYMONTH
SET DEFINE OFF;
REM INSERTING into BANK.TRANSFER_UPDATE_LOG
SET DEFINE OFF;
REM INSERTING into BANK.WITHDRAW
SET DEFINE OFF;
REM INSERTING into BANK.WITHDRAWBYMONTH
SET DEFINE OFF;
REM INSERTING into BANK.W_ATM
SET DEFINE OFF;
REM INSERTING into BANK.W_CHEQUE
SET DEFINE OFF;
--------------------------------------------------------
--  DDL for Index BRANCH_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."BRANCH_PK" ON "BANK"."BRANCH" ("B_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index CREDITCARD_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."CREDITCARD_PK" ON "BANK"."CREDITCARD" ("CREDITCARD_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index ACCOUNT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."ACCOUNT_PK" ON "BANK"."ACCOUNT" ("ACC_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index DEBITCARD_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."DEBITCARD_PK" ON "BANK"."DEBITCARD" ("DEBITCARD_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index LOGIN_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."LOGIN_PK" ON "BANK"."LOGIN" ("U_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index ONNET_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."ONNET_PK" ON "BANK"."ONNET" ("REQ_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index APPROVED_STATUS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."APPROVED_STATUS_PK" ON "BANK"."APPROVED_STATUS" ("APPROVED_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index ACCOUNT_CON
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."ACCOUNT_CON" ON "BANK"."ACCOUNT" ("CREDITCARD_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index WITHDARW_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."WITHDARW_PK" ON "BANK"."WITHDRAW" ("W_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index APPROVED_LOAN_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."APPROVED_LOAN_PK" ON "BANK"."APPROVED_LOAN" ("LOAN_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index ACCOUNT_CL_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."ACCOUNT_CL_ID" ON "BANK"."ACCOUNT" ("CL_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index CLIENT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."CLIENT_PK" ON "BANK"."CLIENT" ("CL_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index PAYMENT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."PAYMENT_PK" ON "BANK"."PAYMENT" ("P_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index PK_LOAN
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."PK_LOAN" ON "BANK"."LOAN" ("LOAN_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index TRANSFER_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."TRANSFER_PK" ON "BANK"."TRANSFER" ("T_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index ACCOUNT_DEBIT
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."ACCOUNT_DEBIT" ON "BANK"."ACCOUNT" ("DEBITCARD_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index EMPLOYEE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."EMPLOYEE_PK" ON "BANK"."EMPLOYEE" ("E_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index DEPOSIT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."DEPOSIT_PK" ON "BANK"."DEPOSIT" ("D_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index PRIMARY_KEY
--------------------------------------------------------

  CREATE UNIQUE INDEX "BANK"."PRIMARY_KEY" ON "BANK"."ATM" ("ATM_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Trigger UPDATED_DEPOSIT
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "BANK"."UPDATED_DEPOSIT" 
after update on Deposit
for each row
begin
insert into Deposit_Update_Log values(:old.d_no,:old.amount,:new.amount,sysdate);
END;
/
ALTER TRIGGER "BANK"."UPDATED_DEPOSIT" ENABLE;
--------------------------------------------------------
--  DDL for Trigger UPDATED_SALARY
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "BANK"."UPDATED_SALARY" 
after update on EMPLOYEE
for each row
begin
insert into salary_log values(:old.e_id,:old.salary,:new.salary,sysdate);
END;
/
ALTER TRIGGER "BANK"."UPDATED_SALARY" ENABLE;
--------------------------------------------------------
--  DDL for Trigger UPDATED_TRANFER
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "BANK"."UPDATED_TRANFER" 
after update on Transfer
for each row
begin
insert into Transfer_Update_Log values(:old.t_no,:old.amount,:new.amount,sysdate);
END;
/
ALTER TRIGGER "BANK"."UPDATED_TRANFER" ENABLE;
--------------------------------------------------------
--  DDL for Procedure ADDPAYMENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "BANK"."ADDPAYMENT" (
loanid in number,bid in number,amnt in number,pdate in date,name in varchar) 
is begin insert into payment values (paymentno.nextval,loanid,bid,amnt,pdate,name); 
update loan set to_bepaid=to_bepaid-amnt where loan_id=loanid; end;

/
--------------------------------------------------------
--  DDL for Procedure NEWACCOUNTCO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "BANK"."NEWACCOUNTCO" (
comname in varchar,rep in varchar,add in varchar,con in number,acctype in varchar,bal in number,bid in number,eid in number) 
as clid client.cl_id%type; acno account.acc_no%type; begin select clno.nextval,accno.nextval into clid,acno from dual; 
insert into client values(clid,add,con); insert into account values(acno,acctype,'','' ,bal,clid,bid,eid,sysdate); 
insert into corporate values(clid,comname,rep); end;

/
--------------------------------------------------------
--  DDL for Procedure NEWACCOUNTCU
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "BANK"."NEWACCOUNTCU" (
nam in varchar,nid in number,add in varchar,con in number,acctype in varchar,bal in number,bid in number,eid in number) 
as clid client.cl_id%type; acno account.acc_no%type; dc debitcard.debitcard_no%type; begin select clno.nextval,accno.nextval,dcard.nextval into 
clid,acno,dc from dual; insert into client values(clid,add,con); insert into account values(acno,acctype,dc,'' ,bal,clid,bid,eid,sysdate); 
insert into personal values(clid,nam,nid); end;

/
--------------------------------------------------------
--  DDL for Procedure NEWACCOUNTFI
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "BANK"."NEWACCOUNTFI" (
nam in varchar,nid in number,add in varchar,con in number,acctype in varchar,bal in number,bid in number,eid in number) 
as clid client.cl_id%type; acno account.acc_no%type; begin select clno.nextval,accno.nextval into clid,acno from dual; 
insert into client values(clid,add,con); insert into account values(acno,acctype,'','' ,bal,clid,bid,eid,sysdate); 
insert into personal values(clid,nam,nid); end;

/
--------------------------------------------------------
--  DDL for Procedure TRANSFERMONEY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "BANK"."TRANSFERMONEY" (
accfrom in number,accto in number,bid in number,amnt in number,tdate in date) 
is sub number:=(-1)*amnt; begin insert into transfer values(tno.nextval,accfrom,accto,bid,amnt,tdate); 
upBalance(accfrom,sub); upBalance(accto,amnt); end;

/
--------------------------------------------------------
--  DDL for Procedure UPBALANCE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "BANK"."UPBALANCE" (
accno in number,amount in number) 
is begin update account set balance=balance+amount where acc_no=accno; end;

/
--------------------------------------------------------
--  DDL for Procedure WITHDRAWBYCHEQUE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "BANK"."WITHDRAWBYCHEQUE" (
amnt in number,accno in number,bid in number,chqno in number,issuedby in varchar,result out varchar) 
as wn withdraw.w_no%type; bal account.balance%type; begin select balance into bal from account where acc_no=accno; 
if bal>=amnt then select wno.nextval into wn from dual; insert into withdraw values(wn,'CHEQUE',sysdate,amnt,accno,bid); 
insert into w_cheque values(wn,chqno,accno,issuedby); bal:=(-1)*amnt; upbalance(accno,bal); result:='SUCCESS'; else result:='FAIL'; end if; end;

/
--------------------------------------------------------
--  Constraints for Table PERSONAL
--------------------------------------------------------

  ALTER TABLE "BANK"."PERSONAL" MODIFY ("CL_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."PERSONAL" MODIFY ("NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table W_CHEQUE
--------------------------------------------------------

  ALTER TABLE "BANK"."W_CHEQUE" MODIFY ("W_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."W_CHEQUE" MODIFY ("CHK_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."W_CHEQUE" MODIFY ("ACC_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."W_CHEQUE" MODIFY ("ISSUED_BY" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ACCOUNT
--------------------------------------------------------

  ALTER TABLE "BANK"."ACCOUNT" ADD CONSTRAINT "ACCOUNT_CK1_BALANCE" CHECK (BALANCE>=500) ENABLE;
 
  ALTER TABLE "BANK"."ACCOUNT" ADD CONSTRAINT "ACCOUNT_CL_ID" UNIQUE ("CL_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."ACCOUNT" ADD CONSTRAINT "ACCOUNT_CON" UNIQUE ("CREDITCARD_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."ACCOUNT" ADD CONSTRAINT "ACCOUNT_DEBIT" UNIQUE ("DEBITCARD_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."ACCOUNT" ADD CONSTRAINT "ACCOUNT_PK" PRIMARY KEY ("ACC_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."ACCOUNT" MODIFY ("ACC_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."ACCOUNT" MODIFY ("ACC_TYPE" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."ACCOUNT" MODIFY ("BALANCE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CREDITCARD
--------------------------------------------------------

  ALTER TABLE "BANK"."CREDITCARD" ADD CONSTRAINT "CREDITCARD_CK1" CHECK (PIN > 999) ENABLE;
 
  ALTER TABLE "BANK"."CREDITCARD" ADD CONSTRAINT "CREDITCARD_PK" PRIMARY KEY ("CREDITCARD_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."CREDITCARD" MODIFY ("CREDITCARD_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."CREDITCARD" MODIFY ("LIMIT" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."CREDITCARD" MODIFY ("EXP_DATE" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."CREDITCARD" MODIFY ("PIN" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table DEPOSIT
--------------------------------------------------------

  ALTER TABLE "BANK"."DEPOSIT" ADD CONSTRAINT "DEPOSIT_CK1" CHECK (amount>100) ENABLE;
 
  ALTER TABLE "BANK"."DEPOSIT" ADD CONSTRAINT "DEPOSIT_PK" PRIMARY KEY ("D_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."DEPOSIT" MODIFY ("D_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."DEPOSIT" MODIFY ("D_NAME" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."DEPOSIT" MODIFY ("D_DATE" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."DEPOSIT" MODIFY ("B_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."DEPOSIT" MODIFY ("ACC_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."DEPOSIT" MODIFY ("AMOUNT" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table WITHDRAW
--------------------------------------------------------

  ALTER TABLE "BANK"."WITHDRAW" MODIFY ("W_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."WITHDRAW" MODIFY ("W_TYPE" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."WITHDRAW" MODIFY ("W_DATE" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."WITHDRAW" MODIFY ("AMOUNT" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."WITHDRAW" MODIFY ("ACC_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."WITHDRAW" MODIFY ("B_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."WITHDRAW" ADD CONSTRAINT "WITHDARW_PK" PRIMARY KEY ("W_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table CLIENT
--------------------------------------------------------

  ALTER TABLE "BANK"."CLIENT" ADD CONSTRAINT "CLIENT_PK" PRIMARY KEY ("CL_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."CLIENT" MODIFY ("CL_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."CLIENT" MODIFY ("ADDRESS" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."CLIENT" MODIFY ("CL_CONTACT" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TRANSFER
--------------------------------------------------------

  ALTER TABLE "BANK"."TRANSFER" MODIFY ("T_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."TRANSFER" MODIFY ("ACC_NO_FROM" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."TRANSFER" MODIFY ("ACC_NO_TO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."TRANSFER" MODIFY ("B_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."TRANSFER" MODIFY ("AMOUNT" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."TRANSFER" MODIFY ("T_DATE" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."TRANSFER" ADD CONSTRAINT "TRANSFER_CK1" CHECK (AMOUNT>0) ENABLE;
 
  ALTER TABLE "BANK"."TRANSFER" ADD CONSTRAINT "TRANSFER_PK" PRIMARY KEY ("T_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table W_ATM
--------------------------------------------------------

  ALTER TABLE "BANK"."W_ATM" MODIFY ("W_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."W_ATM" MODIFY ("ATM_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."W_ATM" MODIFY ("CARD_TYPE" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."W_ATM" MODIFY ("CARD_NO" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table DEPARTMENT
--------------------------------------------------------

  ALTER TABLE "BANK"."DEPARTMENT" ADD PRIMARY KEY ("D_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table LOAN
--------------------------------------------------------

  ALTER TABLE "BANK"."LOAN" ADD CONSTRAINT "PK_LOAN" PRIMARY KEY ("LOAN_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."LOAN" MODIFY ("LOAN_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."LOAN" MODIFY ("INTEREST_RATE" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."LOAN" MODIFY ("LOAN_ON" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."LOAN" MODIFY ("DURATION_MONTH" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."LOAN" MODIFY ("AMOUNT" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table EMPLOYEE
--------------------------------------------------------

  ALTER TABLE "BANK"."EMPLOYEE" ADD CONSTRAINT "EMPLOYEE_PK" PRIMARY KEY ("E_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."EMPLOYEE" MODIFY ("E_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."EMPLOYEE" MODIFY ("E_NAME" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."EMPLOYEE" MODIFY ("SALARY" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."EMPLOYEE" MODIFY ("B_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table LOGIN
--------------------------------------------------------

  ALTER TABLE "BANK"."LOGIN" ADD CONSTRAINT "LOGIN_PK" PRIMARY KEY ("U_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."LOGIN" MODIFY ("E_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."LOGIN" MODIFY ("U_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."LOGIN" MODIFY ("PASSWORD" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ONNET
--------------------------------------------------------

  ALTER TABLE "BANK"."ONNET" ADD CONSTRAINT "ONNET_CK1" CHECK (AMOUNT>0) ENABLE;
 
  ALTER TABLE "BANK"."ONNET" ADD CONSTRAINT "ONNET_PK" PRIMARY KEY ("REQ_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."ONNET" MODIFY ("REQ_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."ONNET" MODIFY ("CARD_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."ONNET" MODIFY ("CARD_TYPE" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."ONNET" MODIFY ("AMOUNT" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."ONNET" MODIFY ("STATUS" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."ONNET" MODIFY ("REQ_DATE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table APPROVED_LOAN
--------------------------------------------------------

  ALTER TABLE "BANK"."APPROVED_LOAN" ADD CONSTRAINT "APPROVED_LOAN_PK" PRIMARY KEY ("LOAN_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."APPROVED_LOAN" MODIFY ("LOAN_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."APPROVED_LOAN" MODIFY ("APPROVER_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."APPROVED_LOAN" MODIFY ("ACC_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."APPROVED_LOAN" MODIFY ("APP_DATE" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."APPROVED_LOAN" MODIFY ("LOAN_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table DEBITCARD
--------------------------------------------------------

  ALTER TABLE "BANK"."DEBITCARD" ADD CONSTRAINT "DEBITCARD_CK1" CHECK (PIN>999) ENABLE;
 
  ALTER TABLE "BANK"."DEBITCARD" ADD CONSTRAINT "DEBITCARD_PK" PRIMARY KEY ("DEBITCARD_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."DEBITCARD" MODIFY ("DEBITCARD_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."DEBITCARD" MODIFY ("VALIDDATE" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."DEBITCARD" MODIFY ("PIN" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CORPORATE
--------------------------------------------------------

  ALTER TABLE "BANK"."CORPORATE" MODIFY ("CL_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."CORPORATE" MODIFY ("COMPANY_NAME" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."CORPORATE" MODIFY ("REPRESENTATOR_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ATM
--------------------------------------------------------

  ALTER TABLE "BANK"."ATM" ADD CONSTRAINT "PRIMARY_KEY" PRIMARY KEY ("ATM_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."ATM" MODIFY ("ATM_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."ATM" MODIFY ("B_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."ATM" MODIFY ("BALANCE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table BRANCH
--------------------------------------------------------

  ALTER TABLE "BANK"."BRANCH" ADD CONSTRAINT "BRANCH_PK" PRIMARY KEY ("B_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."BRANCH" MODIFY ("B_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."BRANCH" MODIFY ("B_NAME" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."BRANCH" MODIFY ("LOCATION" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."BRANCH" MODIFY ("TOTALMONEY" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table PAYMENT
--------------------------------------------------------

  ALTER TABLE "BANK"."PAYMENT" ADD CONSTRAINT "PAYMENT_CK1" CHECK (P_AMOUNT>0) ENABLE;
 
  ALTER TABLE "BANK"."PAYMENT" ADD CONSTRAINT "PAYMENT_PK" PRIMARY KEY ("P_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."PAYMENT" MODIFY ("P_NO" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."PAYMENT" MODIFY ("LOAN_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."PAYMENT" MODIFY ("B_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."PAYMENT" MODIFY ("P_AMOUNT" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."PAYMENT" MODIFY ("P_DATE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table APPROVED_STATUS
--------------------------------------------------------

  ALTER TABLE "BANK"."APPROVED_STATUS" ADD CONSTRAINT "APPROVED_STATUS_PK" PRIMARY KEY ("APPROVED_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BANK"."APPROVED_STATUS" MODIFY ("APPROVED_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BANK"."APPROVED_STATUS" MODIFY ("STATUS" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table ACCOUNT
--------------------------------------------------------

  ALTER TABLE "BANK"."ACCOUNT" ADD CONSTRAINT "FOREIGN_KEY_CL_ID" FOREIGN KEY ("CL_ID")
	  REFERENCES "BANK"."CLIENT" ("CL_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table APPROVED_LOAN
--------------------------------------------------------

  ALTER TABLE "BANK"."APPROVED_LOAN" ADD CONSTRAINT "APPROVED_LOAN_FK" FOREIGN KEY ("APPROVER_ID")
	  REFERENCES "BANK"."EMPLOYEE" ("E_ID") ENABLE;
 
  ALTER TABLE "BANK"."APPROVED_LOAN" ADD CONSTRAINT "APPROVED_LOAN_FK2" FOREIGN KEY ("ACC_NO")
	  REFERENCES "BANK"."ACCOUNT" ("ACC_NO") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ATM
--------------------------------------------------------

  ALTER TABLE "BANK"."ATM" ADD CONSTRAINT "ATM_FK" FOREIGN KEY ("B_ID")
	  REFERENCES "BANK"."BRANCH" ("B_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table CORPORATE
--------------------------------------------------------

  ALTER TABLE "BANK"."CORPORATE" ADD CONSTRAINT "CORPORATE_FK" FOREIGN KEY ("CL_ID")
	  REFERENCES "BANK"."CLIENT" ("CL_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table DEPOSIT
--------------------------------------------------------

  ALTER TABLE "BANK"."DEPOSIT" ADD CONSTRAINT "DEPOSIT_FK" FOREIGN KEY ("ACC_NO")
	  REFERENCES "BANK"."ACCOUNT" ("ACC_NO") ENABLE;
 
  ALTER TABLE "BANK"."DEPOSIT" ADD CONSTRAINT "DEPOSIT_FK2" FOREIGN KEY ("B_ID")
	  REFERENCES "BANK"."BRANCH" ("B_ID") ENABLE;
 
  ALTER TABLE "BANK"."DEPOSIT" ADD CONSTRAINT "FOREIGN_KEY_DEPOSIT_EMP" FOREIGN KEY ("RECEIVER")
	  REFERENCES "BANK"."EMPLOYEE" ("E_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table EMPLOYEE
--------------------------------------------------------

  ALTER TABLE "BANK"."EMPLOYEE" ADD CONSTRAINT "FOREIGN_KEY_EMP" FOREIGN KEY ("B_ID")
	  REFERENCES "BANK"."BRANCH" ("B_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table LOGIN
--------------------------------------------------------

  ALTER TABLE "BANK"."LOGIN" ADD CONSTRAINT "LOGIN_FK" FOREIGN KEY ("E_ID")
	  REFERENCES "BANK"."EMPLOYEE" ("E_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ONNET
--------------------------------------------------------

  ALTER TABLE "BANK"."ONNET" ADD CONSTRAINT "ONNET_FK" FOREIGN KEY ("CARD_NO")
	  REFERENCES "BANK"."CREDITCARD" ("CREDITCARD_NO") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table PAYMENT
--------------------------------------------------------

  ALTER TABLE "BANK"."PAYMENT" ADD CONSTRAINT "PAYMENT_FK3" FOREIGN KEY ("B_ID")
	  REFERENCES "BANK"."BRANCH" ("B_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table PERSONAL
--------------------------------------------------------

  ALTER TABLE "BANK"."PERSONAL" ADD CONSTRAINT "PERSONAL_FK" FOREIGN KEY ("CL_ID")
	  REFERENCES "BANK"."CLIENT" ("CL_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table TRANSFER
--------------------------------------------------------

  ALTER TABLE "BANK"."TRANSFER" ADD CONSTRAINT "TRANSFER_FK" FOREIGN KEY ("ACC_NO_FROM")
	  REFERENCES "BANK"."ACCOUNT" ("ACC_NO") ENABLE;
 
  ALTER TABLE "BANK"."TRANSFER" ADD CONSTRAINT "TRANSFER_FK2" FOREIGN KEY ("ACC_NO_TO")
	  REFERENCES "BANK"."ACCOUNT" ("ACC_NO") ENABLE;
 
  ALTER TABLE "BANK"."TRANSFER" ADD CONSTRAINT "TRANSFER_FK3" FOREIGN KEY ("B_ID")
	  REFERENCES "BANK"."BRANCH" ("B_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table WITHDRAW
--------------------------------------------------------

  ALTER TABLE "BANK"."WITHDRAW" ADD CONSTRAINT "WITHDARW_FK" FOREIGN KEY ("ACC_NO")
	  REFERENCES "BANK"."ACCOUNT" ("ACC_NO") ENABLE;
 
  ALTER TABLE "BANK"."WITHDRAW" ADD CONSTRAINT "WITHDARW_FK2" FOREIGN KEY ("B_ID")
	  REFERENCES "BANK"."BRANCH" ("B_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table W_ATM
--------------------------------------------------------

  ALTER TABLE "BANK"."W_ATM" ADD CONSTRAINT "FOREIGN_KEY_FK_2" FOREIGN KEY ("ATM_ID")
	  REFERENCES "BANK"."ATM" ("ATM_ID") ENABLE;
 
  ALTER TABLE "BANK"."W_ATM" ADD CONSTRAINT "W_ATM_FK" FOREIGN KEY ("W_NO")
	  REFERENCES "BANK"."WITHDRAW" ("W_NO") ENABLE;
 
  ALTER TABLE "BANK"."W_ATM" ADD CONSTRAINT "W_ATM_FK3" FOREIGN KEY ("CARD_NO")
	  REFERENCES "BANK"."DEBITCARD" ("DEBITCARD_NO") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table W_CHEQUE
--------------------------------------------------------

  ALTER TABLE "BANK"."W_CHEQUE" ADD CONSTRAINT "W_CHECK_FK" FOREIGN KEY ("ACC_NO")
	  REFERENCES "BANK"."ACCOUNT" ("ACC_NO") ENABLE;
